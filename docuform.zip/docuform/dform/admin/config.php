<?php
// HTTP
define('HTTP_SERVER', 'http://localhost/dform/admin/');
define('HTTP_CATALOG', 'http://localhost/dform/');
define('HTTP_IMAGE', 'http://localhost/dform/image/');

// HTTPS
define('HTTPS_SERVER', 'http://localhost/dform/admin/');
define('HTTPS_IMAGE', 'http://localhost/dform/image/');

// DIR
define('DIR_APPLICATION', 	'C:\xampp\htdocs\dform/admin/');
define('DIR_SYSTEM', 		'C:\xampp\htdocs\dform/system/');
define('DIR_DATABASE', 		'C:\xampp\htdocs\dform/system/database/');
define('DIR_LANGUAGE', 		'C:\xampp\htdocs\dform/admin/language/');
define('DIR_TEMPLATE', 		'C:\xampp\htdocs\dform/admin/view/template/');
define('DIR_CONFIG', 		'C:\xampp\htdocs\dform/system/config/');
define('DIR_IMAGE', 		'C:\xampp\htdocs\dform/image/');
define('DIR_CACHE', 		'C:\xampp\htdocs\dform/system/cache/');
define('DIR_DOWNLOAD', 		'C:\xampp\htdocs\dform/download/');
define('DIR_LOGS', 			'C:\xampp\htdocs\dform/system/logs/');
define('DIR_CATALOG', 		'C:\xampp\htdocs\dform/catalog/');

// DB
define('DB_DRIVER', 	'mysql');
define('DB_HOSTNAME', 	'localhost');
define('DB_USERNAME', 	'root');
define('DB_PASSWORD', 	'');
define('DB_DATABASE', 	'oswebcom_dform');
define('DB_PREFIX', 	'dform_');
?>