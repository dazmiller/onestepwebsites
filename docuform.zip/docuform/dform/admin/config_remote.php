<?php
// HTTP
define('HTTP_SERVER', 'http://osweb.com.au/dform/opencart/admin/');
define('HTTP_CATALOG', 'http://osweb.com.au/dform/opencart/');
define('HTTP_IMAGE', 'http://osweb.com.au/dform/opencart/image/');

// HTTPS
define('HTTPS_SERVER', 'http://osweb.com.au/dform/opencart/admin/');
define('HTTPS_IMAGE', 'http://osweb.com.au/dform/opencart/image/');

// DIR
define('DIR_APPLICATION', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/admin/');
define('DIR_SYSTEM', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/system/');
define('DIR_DATABASE', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/system/database/');
define('DIR_LANGUAGE', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/admin/language/');
define('DIR_TEMPLATE', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/admin/view/template/');
define('DIR_CONFIG', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/system/config/');
define('DIR_IMAGE', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/image/');
define('DIR_CACHE', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/system/cache/');
define('DIR_DOWNLOAD', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/download/');
define('DIR_LOGS', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/system/logs/');
define('DIR_CATALOG', 'W:\vhosts\osweb.com.au\httpdocs\dform\opencart/catalog/');

// DB
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'osweb_dform');
define('DB_PASSWORD', 'onestep');
define('DB_DATABASE', 'oswebcom_dform');
define('DB_PREFIX', 'dform_');
?>