<?php
// HTTP
define('HTTP_SERVER', 'http://onestep.cloudapp.net/easytv/admin/');
define('HTTP_CATALOG', 'http://onestep.cloudapp.net/easytv/');
define('HTTP_IMAGE', 'http://onestep.cloudapp.net/easytv/image/');

// HTTPS
define('HTTPS_SERVER', 'http://onestep.cloudapp.net/easytv/admin/');
define('HTTPS_CATALOG', 'http://onestep.cloudapp.net/easytv/');
define('HTTPS_IMAGE', 'http://onestep.cloudapp.net/easytv/image/');

// DIR
define('DIR_APPLICATION', 'E:\websites\easytv/admin/');
define('DIR_SYSTEM', 'E:\websites\easytv/system/');
define('DIR_DATABASE', 'E:\websites\easytv/system/database/');
define('DIR_LANGUAGE', 'E:\websites\easytv/admin/language/');
define('DIR_TEMPLATE', 'E:\websites\easytv/admin/view/template/');
define('DIR_CONFIG', 'E:\websites\easytv/system/config/');
define('DIR_IMAGE', 'E:\websites\easytv/image/');
define('DIR_CACHE', 'E:\websites\easytv/system/cache/');
define('DIR_DOWNLOAD', 'E:\websites\easytv/download/');
define('DIR_LOGS', 'E:\websites\easytv/system/logs/');
define('DIR_CATALOG', 'E:\websites\easytv/catalog/');

// DB
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_DATABASE', 'easytv');
define('DB_PREFIX', 'etv');
?>