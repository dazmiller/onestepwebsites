<?php
// Heading
$_['heading_title']      = 'Pay After Confirmation';

// Text
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Pay After Confirmation payment module!';

// Entry
$_['entry_order_status'] = 'Order Status:';
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order:';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify payment Pay After Confirmation!';
?>