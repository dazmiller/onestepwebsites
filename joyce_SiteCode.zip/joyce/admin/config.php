<?php
// HTTP
define('HTTP_SERVER', 'http://onestep.cloudapp.net/joyce/admin/');
define('HTTP_CATALOG', 'http://onestep.cloudapp.net/joyce/');
define('HTTP_IMAGE', 'http://onestep.cloudapp.net/joyce/image/');

// HTTPS
define('HTTPS_SERVER', 'http://onestep.cloudapp.net/joyce/admin/');
define('HTTPS_IMAGE', 'http://onestep.cloudapp.net/joyce/image/');

// DIR
define('DIR_APPLICATION', 'E:\websites\joyce\admin\\');
define('DIR_SYSTEM', 'E:\websites\joyce\system\\');
define('DIR_DATABASE', 'E:\websites\joyce\system\database\\');
define('DIR_LANGUAGE', 'E:\websites\joyce\admin\language\\');
define('DIR_TEMPLATE', 'E:\websites\joyce\admin\view\template\\');
define('DIR_CONFIG', 'E:\websites\joyce\system\config\\');
define('DIR_IMAGE', 'E:\websites\joyce\image\\');
define('DIR_CACHE', 'E:\websites\joyce\system\cache\\');
define('DIR_DOWNLOAD', 'E:\websites\joyce\download\\');
define('DIR_LOGS', 'E:\websites\joyce\system\logs\\');
define('DIR_CATALOG', 'E:\websites\joyce\catalog\\');

// DB
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_DATABASE', 'joycejew');
define('DB_PREFIX', '');

define('CATEGOTY_UNIQUE', 112);
define('CATEGOTY_PROHIBIT', 114);
define('CATEGOTY_MAKEYOUROWN', 46); //Make Your Own

define('CATEGOTY_DIAMONDSHAPE', 131);
define('CATEGOTY_RINGSTYLE', 117);
define('CATEGOTY_RINGMETAL', 125);

define('Deposit_Status_Id', 17);
define('refund_action_id',1); // refund id hardcoded to minus from total 
?>