<?php 
class ControllerCatalogDiamond extends Controller {
 	private $error = array();

  	public function index() {
                $this->load->language('catalog/diamond');

                $this->document->setTitle($this->language->get('heading_title'));   

		$this->load->model('catalog/diamond');

    	$this->getList();
  	}
        public function diamondautocomplete() {
		$json = array();
		if (isset($this->request->get['filter_certNo'])) {
			$this->load->model('catalog/diamond');
                        
			if (isset($this->request->get['filter_certNo'])) {
				$filter_certNo = $this->request->get['filter_certNo'];
			} else {
				$filter_certNo = '';
			}
			if (isset($this->request->get['limit'])) {
				$limit = $this->request->get['limit'];	
			} else {
				$limit = 20;	
			}			
			$data = array(
				'filter_certNo'         => $filter_certNo,
				'start'               => 0,
				'limit'               => $limit
			);
		        $results = $this->model_catalog_diamond->getAutoDiamonds($data);
			
			foreach ($results as $result) {
				$json[] = array(
					'Certno'     => $result['Certno']
				);	
			}
		}

		$this->response->setOutput(json_encode($json));
	}        
        public function info() {
		$this->template = 'catalog/diamond_info.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);
				
		$this->response->setOutput($this->render());    
        }       
	private function getList() {  

		if (isset($this->request->get['filter_certNo'])) {
			$filter_certNo = $this->request->get['filter_certNo'];
		} else {
			$filter_certNo = null;
		}

		if (isset($this->request->get['filter_shape'])) {
			$filter_shape = $this->request->get['filter_shape'];
		} else {
			$filter_shape = null;
		}
                
		if (isset($this->request->get['filter_color'])) {
			$filter_color = $this->request->get['filter_color'];
		} else {
			$filter_color = null;
		}    
                
 		if (isset($this->request->get['filter_purity'])) {
			$filter_purity = $this->request->get['filter_purity'];
		} else {
			$filter_purity = null;
		}
                
 		if (isset($this->request->get['filter_cut'])) {
			$filter_cut = $this->request->get['filter_cut'];
		} else {
			$filter_cut = null;
		}   
                
 		if (isset($this->request->get['filter_sym'])) {
			$filter_sym = $this->request->get['filter_sym'];
		} else {
			$filter_sym = null;
		}                  
                
  		if (isset($this->request->get['filter_pol'])) {
			$filter_pol = $this->request->get['filter_pol'];
		} else {
			$filter_pol = null;
		}  
                
  		if (isset($this->request->get['filter_fluo'])) {
			$filter_fluo = $this->request->get['filter_fluo'];
		} else {
			$filter_fluo = null;
		}
                
  		if (isset($this->request->get['filter_source'])) {
			$filter_source = $this->request->get['filter_source'];
		} else {
			$filter_source = null;
		}                
                
                
 		/*if (isset($this->request->get['filter_ct'])) {
			$filter_ct = $this->request->get['filter_ct'];
		} else {
			$filter_ct = null;
		}*/                    
		
                
		if (isset($this->request->get['filter_price_min'])) {
			$filter_price_min = $this->request->get['filter_price_min'];
		} else {
			$filter_price_min = null;
		}
                
                if (isset($this->request->get['filter_price_max'])) {
			$filter_price_max = $this->request->get['filter_price_max'];
		} else {
			$filter_price_max = null;
		}
                
 		if (isset($this->request->get['filter_Tprice_min'])) {
			$filter_Tprice_min = $this->request->get['filter_Tprice_min'];
		} else {
			$filter_Tprice_min = null;
		}
                
                if (isset($this->request->get['filter_Tprice_max'])) {
			$filter_Tprice_max = $this->request->get['filter_Tprice_max'];
		} else {
			$filter_Tprice_max = null;
		}
                
 		if (isset($this->request->get['filter_ct_min'])) {
			$filter_ct_min = $this->request->get['filter_ct_min'];
		} else {
			$filter_ct_min = null;
		}
                
                if (isset($this->request->get['filter_ct_max'])) {
			$filter_ct_max = $this->request->get['filter_ct_max'];
		} else {
			$filter_ct_max = null;
		}              
                
                
		if (isset($this->request->get['filter_status'])) {
			$filter_status = $this->request->get['filter_status'];
		} else {
			$filter_status = null;
		}

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'Shape';
		}
		
		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}
		
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
						
		$url = '';
						
		if (isset($this->request->get['filter_certNo'])) {
			$url .= '&filter_certNo=' . $this->request->get['filter_certNo'];
		}
		
		if (isset($this->request->get['filter_shape'])) {
			$url .= '&filter_shape=' . $this->request->get['filter_shape'];
		}
		
		if (isset($this->request->get['filter_color'])) {
			$url .= '&filter_color=' . $this->request->get['filter_color'];
		}
		
		if (isset($this->request->get['filter_purity'])) {
			$url .= '&filter_purity=' . $this->request->get['filter_purity'];
		}
		
		if (isset($this->request->get['filter_cut'])) {
			$url .= '&filter_cut=' . $this->request->get['filter_cut'];
		}
		
		if (isset($this->request->get['filter_sym'])) {
			$url .= '&filter_sym=' . $this->request->get['filter_sym'];
		}
		
		if (isset($this->request->get['filter_pol'])) {
			$url .= '&filter_pol=' . $this->request->get['filter_pol'];
		}
		
		if (isset($this->request->get['filter_fluo'])) {
			$url .= '&filter_fluo=' . $this->request->get['filter_fluo'];
		}
                
		if (isset($this->request->get['filter_source'])) {
			$url .= '&filter_source=' . $this->request->get['filter_source'];
		}                
		
		/*if (isset($this->request->get['filter_ct'])) {
			$url .= '&filter_ct=' . $this->request->get['filter_ct'];
		}*/
		
		if (isset($this->request->get['filter_price_min'])) {
			$url .= '&filter_price_min=' . $this->request->get['filter_price_min'];
		}
                
                if (isset($this->request->get['filter_price_max'])) {
			$url .= '&filter_price_max=' . $this->request->get['filter_price_max'];
		}
                
		if (isset($this->request->get['filter_Tprice_min'])) {
			$url .= '&filter_Tprice_min=' . $this->request->get['filter_Tprice_min'];
		}
                
                if (isset($this->request->get['filter_Tprice_max'])) {
			$url .= '&filter_Tprice_max=' . $this->request->get['filter_Tprice_max'];
		}
		if (isset($this->request->get['filter_ct_min'])) {
			$url .= '&filter_ct_min=' . $this->request->get['filter_ct_min'];
		}
                
                if (isset($this->request->get['filter_ct_max'])) {
			$url .= '&filter_ct_max=' . $this->request->get['filter_ct_max'];
		}                
                

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
						
		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

  		$this->data['breadcrumbs'] = array();

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('catalog/diamond', 'token=' . $this->session->data['token'] . $url, 'SSL'),       		
      		'separator' => ' :: '
   		);

		
		$this->data['diamonds'] = array();
//                        'filter_ct' => $filter_ct,
		$data = array(
                        'filter_certNo'   => $filter_certNo,
			'filter_shape'	  => $filter_shape, 
			'filter_color'	  => $filter_color,
                        'filter_purity'   => $filter_purity,
                        'filter_cut'      => $filter_cut,
			'filter_sym'	  => $filter_sym,
                        'filter_pol'      => $filter_pol,
                        'filter_fluo'     => $filter_fluo,  
                        'filter_source'     => $filter_source, 
			'filter_price_min'	  => $filter_price_min,
                        'filter_price_max'	  => $filter_price_max,
			'filter_Tprice_min'	  => $filter_Tprice_min,
                        'filter_Tprice_max'	  => $filter_Tprice_max,                    
			'filter_ct_min'	  => $filter_ct_min,
                        'filter_ct_max'	  => $filter_ct_max,
			'filter_status'   => $filter_status,
			'sort'            => $sort,
			'order'           => $order,
			'start'           => ($page - 1) * $this->config->get('config_admin_limit'),
			'limit'           => $this->config->get('config_admin_limit')
		);

		$this->load->model('tool/image');
	
		$diamond_total =$this->model_catalog_diamond->getTotalDiamonds($data);
                
                $diamondSelectBox=$this->model_catalog_diamond->getDiamondSelectBox();
                $this->data['shapeSelectBox']=$diamondSelectBox['shape'];
                $this->data['colorSelectBox']=$diamondSelectBox['color'];
                $this->data['puritySelectBox']=$diamondSelectBox['purity'];
                $this->data['cutSelectBox']=$diamondSelectBox['cut'];
                $this->data['ctSelectBox']=$diamondSelectBox['ct'];
                $this->data['symSelectBox']=$diamondSelectBox['sym'];
                $this->data['polSelectBox']=$diamondSelectBox['pol'];
                $this->data['fluoSelectBox']=$diamondSelectBox['fluo'];  
                $this->data['sourceSelectBox']=$diamondSelectBox['source'];

		$results = $this->model_catalog_diamond->getDiamonds($data);
		    	
		foreach ($results as $result) {
			$action = array();
			
			$action[] = array(
				'text' => $this->language->get('text_view'),
				'href' => $this->url->link('catalog/diamond/info', 'token=' . $this->session->data['token'] . '&diamond_id=' . $result['ID'] . $url, 'SSL')
			);			
                    
			if ($result['shape_image'] && file_exists(DIR_IMAGE . $result['shape_image'])) {
				$image = $this->model_tool_image->resize($result['shape_image'], 40, 40);
			} else {
				$image = $this->model_tool_image->resize('no_image.jpg', 40, 40);
			}
                        $diamond_status = $this->model_catalog_diamond->getDiamondStatus($result['ID']);
                        
                        if($diamond_status>0)
                           $diamond_status=$this->language->get('text_status');
                        else
                           $diamond_status='';                            
                        
                        $this->data['diamonds'][] = array(
				'diamond_id' => $result['ID'],
				'certNo'     => $result['Certno'],
                                'shape'     => $result['Shape'],
				'color'      => $result['Color'],
 				'purity'     => $result['Purity'],
                                'clarity'    => $result['Clar'],
                                'cut'        => $result['Cut'],
                                'sym'        => $result['Sym'],                            
                                'pol'        => $result['Pol'],                            
                                'fluo'       => $result['Fluo'],                            
                                'ct'         => $result['Ct'],
                                'TotalPrice'  => $result['TotalPrice'],
				'MarkupedPrice' => $result['MarkupedPrice'],
                                'Source'      => $result['Source'],                            
				'image'      => $image,
				'status'     => $diamond_status,
                                'action'     => $action
			);
            }

		$this->data['heading_title'] = $this->language->get('heading_title');		
				
		$this->data['text_enabled'] = $this->language->get('text_enabled');		
		$this->data['text_disabled'] = $this->language->get('text_disabled');		
		$this->data['text_no_results'] = $this->language->get('text_no_results');		
		$this->data['text_image_manager'] = $this->language->get('text_image_manager');		
		$this->data['text_status'] =$this->language->get('text_status');
                $this->data['text_available'] =$this->language->get('text_available');
                
		$this->data['column_image'] = $this->language->get('column_image');
                
                $this->data['column_certNo'] = $this->language->get('column_certNo');
		$this->data['column_shape'] = $this->language->get('column_shape');		
		$this->data['column_color'] = $this->language->get('column_color');		
		$this->data['column_price'] = $this->language->get('column_price');		
		$this->data['column_purity'] = $this->language->get('column_purity');		
		$this->data['column_status'] = $this->language->get('column_status');		
		$this->data['column_cut'] = $this->language->get('column_cut');		
		$this->data['column_ct'] = $this->language->get('column_ct');		                
		$this->data['column_action'] = $this->language->get('column_action1');		
 		$this->data['column_TotalPrice'] = $this->language->get('column_TotalPrice');	               
 		$this->data['column_Total_markup'] = $this->language->get('column_Total_markup');
                $this->data['column_supplier'] = $this->language->get('column_supplier');                
		$this->data['column_symmetry'] = $this->language->get('column_symmetry');		
 		$this->data['column_polish'] = $this->language->get('column_polish');	               
 		$this->data['column_fluorescence'] = $this->language->get('column_fluorescence');                    
				
		$this->data['button_copy'] = $this->language->get('button_copy');		
		$this->data['button_insert'] = $this->language->get('button_insert');		
		$this->data['button_delete'] = $this->language->get('button_delete');		
		$this->data['button_filter'] = $this->language->get('button_filter');
		 
 		$this->data['token'] = $this->session->data['token'];
		
 		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];
		
			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}

		$url = '';
                
		if (isset($this->request->get['filter_certNo'])) {
			$url .= '&filter_certNo=' . $this->request->get['filter_certNo'];
		}
		
		if (isset($this->request->get['filter_shape'])) {
			$url .= '&filter_shape=' . $this->request->get['filter_shape'];
		}
		
		if (isset($this->request->get['filter_color'])) {
			$url .= '&filter_color=' . $this->request->get['filter_color'];
		}
		
		if (isset($this->request->get['filter_purity'])) {
			$url .= '&filter_purity=' . $this->request->get['filter_purity'];
		}
		
		if (isset($this->request->get['filter_cut'])) {
			$url .= '&filter_cut=' . $this->request->get['filter_cut'];
		}
		
		if (isset($this->request->get['filter_sym'])) {
			$url .= '&filter_sym=' . $this->request->get['filter_sym'];
		}
		
		if (isset($this->request->get['filter_pol'])) {
			$url .= '&filter_pol=' . $this->request->get['filter_pol'];
		}
		
		if (isset($this->request->get['filter_fluo'])) {
			$url .= '&filter_fluo=' . $this->request->get['filter_fluo'];
		}
                
		if (isset($this->request->get['filter_source'])) {
			$url .= '&filter_source=' . $this->request->get['filter_source'];
		}                
                
		
		/*if (isset($this->request->get['filter_ct'])) {
			$url .= '&filter_ct=' . $this->request->get['filter_ct'];
		}*/
		
		if (isset($this->request->get['filter_price_min'])) {
			$url .= '&filter_price_min=' . $this->request->get['filter_price_min'];
		}
                
                if (isset($this->request->get['filter_price_max'])) {
			$url .= '&filter_price_max=' . $this->request->get['filter_price_max'];
		}
		if (isset($this->request->get['filter_Tprice_min'])) {
			$url .= '&filter_Tprice_min=' . $this->request->get['filter_Tprice_min'];
		}
                
                if (isset($this->request->get['filter_Tprice_max'])) {
			$url .= '&filter_Tprice_max=' . $this->request->get['filter_Tprice_max'];
		}
		if (isset($this->request->get['filter_ct_min'])) {
			$url .= '&filter_ct_min=' . $this->request->get['filter_ct_min'];
		}
                
                if (isset($this->request->get['filter_ct_max'])) {
			$url .= '&filter_ct_max=' . $this->request->get['filter_ct_max'];
		}  
                
		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}
								
		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
					
		/*$this->data['sort_name'] = $this->url->link('catalog/diamond', 'token=' . $this->session->data['token'] . '&sort=pd.name' . $url, 'SSL');
                $this->data['sort_category'] = $this->url->link('catalog/diamond', 'token=' . $this->session->data['token'] . '&sort=pd.category' . $url, 'SSL');
		$this->data['sort_model'] = $this->url->link('catalog/diamond', 'token=' . $this->session->data['token'] . '&sort=p.model' . $url, 'SSL');
		$this->data['sort_price'] = $this->url->link('catalog/diamond', 'token=' . $this->session->data['token'] . '&sort=p.price' . $url, 'SSL');
		$this->data['sort_quantity'] = $this->url->link('catalog/diamond', 'token=' . $this->session->data['token'] . '&sort=p.quantity' . $url, 'SSL');
		$this->data['sort_status'] = $this->url->link('catalog/diamond', 'token=' . $this->session->data['token'] . '&sort=p.status' . $url, 'SSL');
		$this->data['sort_order'] = $this->url->link('catalog/diamond', 'token=' . $this->session->data['token'] . '&sort=p.sort_order' . $url, 'SSL');*/
		
		$url = '';

		if (isset($this->request->get['filter_certNo'])) {
			$url .= '&filter_certNo=' . $this->request->get['filter_certNo'];
		}
		
		if (isset($this->request->get['filter_shape'])) {
			$url .= '&filter_shape=' . $this->request->get['filter_shape'];
		}
		
		if (isset($this->request->get['filter_color'])) {
			$url .= '&filter_color=' . $this->request->get['filter_color'];
		}
		
		if (isset($this->request->get['filter_purity'])) {
			$url .= '&filter_purity=' . $this->request->get['filter_purity'];
		}
		
		if (isset($this->request->get['filter_cut'])) {
			$url .= '&filter_cut=' . $this->request->get['filter_cut'];
		}
		
		if (isset($this->request->get['filter_sym'])) {
			$url .= '&filter_sym=' . $this->request->get['filter_sym'];
		}
		
		if (isset($this->request->get['filter_pol'])) {
			$url .= '&filter_pol=' . $this->request->get['filter_pol'];
		}
		
		if (isset($this->request->get['filter_fluo'])) {
			$url .= '&filter_fluo=' . $this->request->get['filter_fluo'];
		}
		if (isset($this->request->get['filter_source'])) {
			$url .= '&filter_source=' . $this->request->get['filter_source'];
		}                 
		
		/*if (isset($this->request->get['filter_ct'])) {
			$url .= '&filter_ct=' . $this->request->get['filter_ct'];
		}*/
		
		if (isset($this->request->get['filter_price_min'])) {
			$url .= '&filter_price_min=' . $this->request->get['filter_price_min'];
		}
                
                if (isset($this->request->get['filter_price_max'])) {
			$url .= '&filter_price_max=' . $this->request->get['filter_price_max'];
		}
 		if (isset($this->request->get['filter_Tprice_min'])) {
			$url .= '&filter_Tprice_min=' . $this->request->get['filter_Tprice_min'];
		}
                
                if (isset($this->request->get['filter_Tprice_max'])) {
			$url .= '&filter_Tprice_max=' . $this->request->get['filter_Tprice_max'];
		}
		if (isset($this->request->get['filter_ct_min'])) {
			$url .= '&filter_ct_min=' . $this->request->get['filter_ct_min'];
		}
                
                if (isset($this->request->get['filter_ct_max'])) {
			$url .= '&filter_ct_max=' . $this->request->get['filter_ct_max'];
		}                 

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
												
		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
				
		$pagination = new Pagination();
		$pagination->total = $diamond_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_admin_limit');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('catalog/diamond', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');
			
		$this->data['pagination'] = $pagination->render();
	
                
                $this->data['filter_certNo'] = $filter_certNo;
		$this->data['filter_shape'] = $filter_shape;
		$this->data['filter_color'] = $filter_color;
                $this->data['filter_purity'] = $filter_purity;
                $this->data['filter_cut'] = $filter_cut;
                $this->data['filter_sym'] = $filter_sym;                
                $this->data['filter_pol'] = $filter_pol;               
                $this->data['filter_fluo'] = $filter_fluo;   
                $this->data['filter_source'] = $filter_source; 
                
               // $this->data['filter_ct'] = $filter_ct;
		$this->data['filter_price_min'] = $filter_price_min;
                $this->data['filter_price_max'] = $filter_price_max;
		$this->data['filter_Tprice_min'] = $filter_Tprice_min;
                $this->data['filter_Tprice_max'] = $filter_Tprice_max;
		$this->data['filter_ct_min'] = $filter_ct_min;
                $this->data['filter_ct_max'] = $filter_ct_max;                
		$this->data['filter_status'] = $filter_status;
		
		$this->data['sort'] = $sort;
		$this->data['order'] = $order;

		$this->template = 'catalog/diamond_list.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);
				
		$this->response->setOutput($this->render());
  	}
}
?>