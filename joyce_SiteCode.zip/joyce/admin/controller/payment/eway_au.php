<?php
class ControllerPaymentEwayAU extends Controller {
	private $error = array();

	public function index() {

		//if (!isset($this->session->data['token'])) {
		//	$this->session->data['token'] = 0;
		//}
		//$this->data['token'] = $this->session->data['token'];

		$this->load->language('payment/eway_au');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validate())) {

            //Add return url here
            $this->request->post['eway_au_return'] = HTTP_CATALOG."index.php?route=payment/eway_au/callback";

			$this->model_setting_setting->editSetting('eway_au', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

            $this->redirect($this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$this->data['heading_title'] = $this->language->get('heading_title');

		$this->data['text_enabled'] = $this->language->get('text_enabled');
		$this->data['text_disabled'] = $this->language->get('text_disabled');
		$this->data['text_all_zones'] = $this->language->get('text_all_zones');
		$this->data['text_none'] = $this->language->get('text_none');
		$this->data['text_yes'] = $this->language->get('text_yes');
		$this->data['text_no'] = $this->language->get('text_no');
		$this->data['text_authorization'] = $this->language->get('text_authorization');
		$this->data['text_sale'] = $this->language->get('text_sale');

		$this->data['entry_email'] = $this->language->get('entry_email');
		$this->data['entry_test'] = $this->language->get('entry_test');
		$this->data['entry_transaction'] = $this->language->get('entry_transaction');
		$this->data['entry_order_status'] = $this->language->get('entry_order_status');
		$this->data['entry_geo_zone'] = $this->language->get('entry_geo_zone');
		$this->data['entry_status'] = $this->language->get('entry_status');
		$this->data['entry_customerid'] = $this->language->get('entry_customerid');

        //Help array here
        $helplist = array( 'help_testmode','help_customerid','help_ewaystatus','help_setorderstatus','help_sort_order' );
        $this->getlanguagestuff($helplist);

		$this->data['entry_sort_order'] = $this->language->get('entry_sort_order');

		$this->data['button_save'] = $this->language->get('button_save');
		$this->data['button_cancel'] = $this->language->get('button_cancel');

		$this->data['tab_general'] = $this->language->get('tab_general');

 		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

 		if (isset($this->error['customerid'])) {
			$this->data['error_customerid'] = $this->error['customerid'];
		} else {
			$this->data['error_customerid'] = '';
		}

        $this->data['breadcrumbs'] = array();

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),       		
      		'separator' => false
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_payment'),
			'href'      => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('payment/eway_au', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

        $this->data['action'] = $this->url->link('payment/eway_au', 'token=' . $this->session->data['token'], 'SSL');
		
		$this->data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');

		if (isset($this->request->post['eway_au_payment_gateway'])) {
			$this->data['eway_au_payment_gateway'] = $this->request->post['eway_au_payment_gateway'];
		} else {
			$this->data['eway_au_payment_gateway'] = $this->config->get('eway_au_payment_gateway');
		}

		if (isset($this->request->post['eway_au_test'])) {
			$this->data['eway_au_test'] = $this->request->post['eway_au_test'];
		} else {
			$this->data['eway_au_test'] = $this->config->get('eway_au_test');
		}

		if (isset($this->request->post['eway_au_transaction'])) {
			$this->data['eway_au_transaction'] = $this->request->post['eway_au_transaction'];
		} else {
			$this->data['eway_au_transaction'] = $this->config->get('eway_au_transaction');
		}

		if (isset($this->request->post['eway_au_order_status_id'])) {
			$this->data['eway_au_order_status_id'] = $this->request->post['eway_au_order_status_id'];
		} else {
			$this->data['eway_au_order_status_id'] = $this->config->get('eway_au_order_status_id');
		}

		$this->load->model('localisation/order_status');
		$this->data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();


		if (isset($this->request->post['eway_au_customerid'])) {
			$this->data['eway_au_customerid'] = $this->request->post['eway_au_customerid'];
		} else {
			$this->data['eway_au_customerid'] = $this->config->get('eway_au_customerid');
		}


/*
		if (isset($this->request->post['eway_au_geo_zone_id'])) {
			$this->data['eway_au_geo_zone_id'] = $this->request->post['eway_au_geo_zone_id'];
		} else {
			$this->data['eway_au_geo_zone_id'] = $this->config->get('eway_au_geo_zone_id');
		}

		$this->load->model('localisation/geo_zone');
		$this->data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();


		$this->load->model('localisation/language');
		$this->data['eway_au_language'] = $this->model_localisation_language->getLanguages();

		if (isset($this->request->post['eway_au_language_id'])) {
			$this->data['eway_au_language_id'] = $this->request->post['eway_au_language_id'];
		} else {
			$this->data['eway_au_language_id'] = $this->config->get('eway_au_language_id');
		}

		$this->data['eway_au_language'] = $this->config->get('eway_au_language_id');

*/

		if (isset($this->request->post['eway_au_status'])) {
			$this->data['eway_au_status'] = $this->request->post['eway_au_status'];
		} else {
			$this->data['eway_au_status'] = $this->config->get('eway_au_status');
		}

		if (isset($this->request->post['eway_au_sort_order'])) {
			$this->data['eway_au_sort_order'] = $this->request->post['eway_au_sort_order'];
		} else {
			$this->data['eway_au_sort_order'] = $this->config->get('eway_au_sort_order');
		}

		$this->template = 'payment/eway_au.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);

		$this->response->setOutput($this->render(TRUE), $this->config->get('config_compression'));

	}

    //JD function to quickly loop through arrays from language files instead of
    //writing out all those lines over and over
    private function getlanguagestuff($helplist) {
        foreach( $helplist as $key ) {
                //$this->data['help_testmode'] = $this->language->get('help_testmode');
                $this->data[$key] = $this->language->get($key);
        }
    }

	private function validate() {
		if (!$this->user->hasPermission('modify', 'payment/eway_au'))
		{
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['eway_au_customerid']) {
			$this->error['customerid'] = $this->language->get('error_customerid');
		}

		if (!$this->error) {
			return TRUE;
		} else {
			return FALSE;
		}
	}
}
?>