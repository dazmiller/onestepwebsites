<?php
// Heading
$_['heading_title']       = 'Carat Margin Markup';

// Text
$_['text_success']        = 'Success: You have modified Carat Margins Markup!';

// Column
$_['column_name']         = 'Shape';
$_['column_start_carat']  = 'Start Carat';
$_['column_finish_carat'] = 'Finish Carat';
$_['column_multiply']     = 'Multiply';
$_['column_action']       = 'Action';

// Entry
$_['entry_shape']        = 'Shape:';
$_['entry_start_carat']  = 'Start Carat:';
$_['entry_finish_carat'] = 'Finish Carat:';
$_['entry_multiply']     = 'Multiply:';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Carat Margins Markup!';
$_['error_shape']         = 'Warning: Carat Margin Shape Required!';
?>