<?php
/* Developer: Ekrem KAYA
Web Page: www.e-piksel.com */

// E-Menu
$_['text_emenu_add_product']	= 'Add Product';
$_['text_emenu_products']		= 'Product';
$_['text_emenu_add_category']	= 'Add Category';
$_['text_emenu_categories']		= 'Categories';
$_['text_emenu_options']		= 'Options';
$_['text_emenu_manufacturer']	= 'Manufacturer';
$_['text_emenu_information']	= 'Information';
$_['text_emenu_reviews']		= 'Reviews';
$_['text_emenu_orders']			= 'Orders';
$_['text_emenu_returns']		= 'Returns';
$_['text_emenu_customers']		= 'Customers';
$_['text_emenu_coupons']		= 'Coupons';
$_['text_emenu_mail']			= 'Mail';
$_['text_emenu_settings']		= 'Settings';
$_['text_emenu_purchased']		= 'Purchased';
$_['text_emenu_backup_restore']	= 'Backup / Restore';
?>