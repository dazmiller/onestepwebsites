<?php
// Text
$_['text_footer'] = '<a href="http://www.onestepsolutions.com.au/" target="_blank">One Step Solutions</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.<br />Version %s';
?>