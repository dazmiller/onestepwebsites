<?php
class ModelCatalogCaratMargin extends Model {
	public function addCaratMargin($data) {
            
           for($i=0; $i<count($data['shape']); $i++)
           {
               $shape=$data['shape'][$i];
               $start_carat=$data['start_carat'][$i];
               $finish_carat=$data['finish_carat'][$i];
               $multiply=$data['multiply'][$i];    
               
               $this->db->query("INSERT INTO `" . DB_PREFIX . "caratmargin` SET SHAPE = '" . $this->db->escape($shape) . "', START_CARAT = '" . $start_carat . "', FINISH_CARAT = '" . $finish_carat . "', MULTIPLY = '" . $multiply . "'"); 
           }
	}
	
	public function editCaratMargin($caratMargin_id, $data) {
           $this->db->query("UPDATE `" . DB_PREFIX . "caratmargin` SET SHAPE = '" . $this->db->escape($data['shape'][0]) . "', START_CARAT = '" . $data['start_carat'][0] . "', FINISH_CARAT = '" . $data['finish_carat'][0] . "', MULTIPLY = '" . $data['multiply'][0] . "' WHERE ID = '" . (int)$caratMargin_id . "'");            
	}
	
	public function deleteCaratMargin($caratMargin_id) {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "caratmargin` WHERE ID = '" . (int)$caratMargin_id . "'");
	}
	
	public function getCaratMargin($caratMargin_id) {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "caratmargin` WHERE ID='".(int)$caratMargin_id."'");
		return $query->row;
	}
		
	public function getCaratMargins($data = array()) {
		$sql = "SELECT * FROM `" . DB_PREFIX . "caratmargin`";
		$sort_data = array(
			'SHAPE',
                        'START_CARAT',
                        'FINISH_CARAT',
                        'MARGIN '
		);	
		
		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];	
		} else {
			$sql .= " ORDER BY ID+0";	
		}
		
		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}
		
		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}					

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}	
		
			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}	
		
		$query = $this->db->query($sql);

		return $query->rows;
	}
	public function getTotalCaratMargins() {
      	$query = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "caratmargin`"); 
		
		return $query->row['total'];
	}
	public function checkCaratMargin() {
		$create_faq = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "caratmargin` (`ID` int(11) NOT NULL auto_increment, `SHAPE` varchar(30)  NOT NULL, `START_CARAT` decimal(10,2)  NOT NULL,`FINISH_CARAT` decimal(10,2) NOT NULL,`MULTIPLY` decimal(10,2) NOT NULL, PRIMARY KEY  (`ID`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;";
		$this->db->query($create_faq);
	}        
}
?>