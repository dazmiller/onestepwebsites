<?php
class ModelCatalogDiamond extends Model {
	public function getAutoDiamonds($data = array()) {
		if ($data) {
                        $sql = "SELECT DISTINCT Certno as Certno FROM " . DB_PREFIX . "v_joyce";

			if (!empty($data['filter_certNo'])) {
				$sql .= " WHERE LCASE(Certno) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_certNo'])) . "%'";
			}
 			if (isset($data['start']) || isset($data['limit'])) {
				if ($data['start'] < 0) {
					$data['start'] = 0;
				}				

				if ($data['limit'] < 1) {
					$data['limit'] = 20;
				}	
			
				$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
			}                       
                        
		} else {

                        $sql = "SELECT DISTINCT Certno as Certno FROM " . DB_PREFIX . "v_joyce";  
		}
                $query = $this->db->query($sql);
                return $query->rows;
	}
    	public function getDiamondSelectBox() {
            $selectBox=array();
            
            /*$queryShape= $this->db->query("SELECT DISTINCT Shape as shape FROM " . DB_PREFIX . "v_joyce");
            $selectBox['shape']=$queryShape->rows;
            
            $queryPurity= $this->db->query("SELECT DISTINCT Purity as purity FROM " . DB_PREFIX . "v_joyce");
            $selectBox['purity']=$queryPurity->rows;
            
            $queryColor= $this->db->query("SELECT DISTINCT Color as color FROM " . DB_PREFIX . "v_joyce");
            $selectBox['color']=$queryColor->rows; 
            
            $queryCut= $this->db->query("SELECT DISTINCT Cut as cut FROM " . DB_PREFIX . "v_joyce");
            $selectBox['cut']=$queryCut->rows;    
            
            $queryCt= $this->db->query("SELECT DISTINCT Ct as ct FROM " . DB_PREFIX . "v_joyce");
            $selectBox['ct']=$queryCt->rows;     */
            
            $queryShape= $this->db->query("SELECT DISTINCT shape as shape FROM " . DB_PREFIX . "shape");
            $selectBox['shape']=$queryShape->rows;
            
            $queryPurity= $this->db->query("SELECT DISTINCT clarity as purity FROM " . DB_PREFIX . "claritypriority");
            $selectBox['purity']=$queryPurity->rows;
            
            $queryColor= $this->db->query("SELECT DISTINCT colorname as color FROM " . DB_PREFIX . "colorpriority");
            $selectBox['color']=$queryColor->rows; 
            
            $queryCut= $this->db->query("SELECT DISTINCT cut as cut FROM " . DB_PREFIX . "cutpriority");
            $selectBox['cut']=$queryCut->rows;  
            
            $queryPurity= $this->db->query("SELECT DISTINCT symmetry as sym FROM " . DB_PREFIX . "symmetrypriority");
            $selectBox['sym']=$queryPurity->rows;
            
            $queryColor= $this->db->query("SELECT DISTINCT polish as pol FROM " . DB_PREFIX . "polishpriority");
            $selectBox['pol']=$queryColor->rows; 
            
            $queryCut= $this->db->query("SELECT DISTINCT fluorescence as fluo FROM " . DB_PREFIX . "fluorescencepriority");
            $selectBox['fluo']=$queryCut->rows;
            
            $queryCt= $this->db->query("SELECT DISTINCT Ct as ct FROM " . DB_PREFIX . "v_joyce");
            $selectBox['ct']=$queryCt->rows; 
            
            $sql="SELECT DISTINCT Source as source FROM " . DB_PREFIX . "v_joyce WHERE ID!=''";
            //$sql.=" AND Certno IS NOT NULL";
           // $sql.=" AND Certno IS NOT NULL AND Certno!='' AND Shape IS NOT NULL AND Shape!='' AND Color IS NOT NULL AND Color!='' AND Purity IS NOT NULL AND Purity!='' AND cut IS NOT NULL AND cut!=''  AND Sym IS NOT NULL AND Sym!='' AND Pol IS NOT NULL AND Pol!='' AND Fluo IS NOT NULL AND Fluo!='' AND Fluo!='NONE' AND Ct IS NOT NULL AND Ct!='' AND TotalPrice IS NOT NULL AND TotalPrice!='' AND Total_markup IS NOT NULL AND Total_markup!=''";			
            $querySource= $this->db->query($sql);
            $selectBox['source']=$querySource->rows;             
            
            return $selectBox;            
        }
	public function getTotalDiamonds($data = array()) {
                 $sql = "SELECT COUNT(DISTINCT ID) AS total from (
                    SELECT  v.*, ROUND( REPLACE( v.TotalPrice,  ',',  '' ) * IFNULL( cm.MULTIPLY, 1 ) ) AS MarkupedPrice
                    FROM  `" . DB_PREFIX . "v_joyce` AS v , `" . DB_PREFIX . "caratmargin` AS cm WHERE cm.SHAPE = v.Shape
                    AND (
                    v.Ct
                    BETWEEN cm.START_CARAT
                    AND cm.FINISH_CARAT
                    )
                    ) as p WHERE ID!=''	
                    ";
            
		//$sql = "SELECT COUNT(DISTINCT ID) AS total FROM " . DB_PREFIX . "v_joyce WHERE ID!='' ";
	        //$sql.=" AND Certno IS NOT NULL AND Certno!='' AND Shape IS NOT NULL AND Shape!='' AND Color IS NOT NULL AND Color!='' AND Purity IS NOT NULL AND Purity!='' AND cut IS NOT NULL AND cut!=''  AND Sym IS NOT NULL AND Sym!='' AND Pol IS NOT NULL AND Pol!='' AND Fluo IS NOT NULL AND Fluo!='' AND Fluo!='NONE' AND Ct IS NOT NULL AND Ct!='' AND TotalPrice IS NOT NULL AND TotalPrice!='' AND Total_markup IS NOT NULL AND Total_markup!=''";			
		$sql.=" AND Certno IS NOT NULL AND Certno!=''";
                if (!empty($data['filter_certNo'])) {
			$sql .= " AND LCASE(Certno) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_certNo'])) . "%'";
		}

		if (!empty($data['filter_shape'])) {
			$sql .= " AND LCASE(Shape) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_shape'])) . "%'";
		}
                
 		if (!empty($data['filter_color'])) {
			$sql .= " AND LCASE(Color) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_color'])) . "%'";
		}
                
		if (!empty($data['filter_purity'])) {
                                $sql .= " AND ((LCASE(Purity) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_purity'])) . "%') OR (LCASE(Clar) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_purity'])) . "%')) ";
		}
                
 		if (!empty($data['filter_cut'])) {
			$sql .= " AND LCASE(Cut) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_cut'])) . "%'";
		} 
                
 		if (!empty($data['filter_sym'])) {
			$sql .= " AND LCASE(Sym) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_sym'])) . "%'";
		}                 

               if (!empty($data['filter_pol'])) {
			$sql .= " AND LCASE(Pol) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_pol'])) . "%'";
		} 
                
 		if (!empty($data['filter_fluo'])) {
			$sql .= " AND LCASE(Fluo) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_fluo'])) . "%'";
		}
                
 		if (!empty($data['filter_source'])) {
			$sql .= " AND LCASE(Source) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_source'])) . "%'";
		}                 
                
 		/*if (!empty($data['filter_ct'])) {
			$sql .= " AND LCASE(Ct) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_ct'])) . "%'";
		}*/  
                
                if (!empty($data['filter_price_min'] ) || !empty($data['filter_price_max'] )) {
                    if(empty($data['filter_price_min']))
                        $sql .= " AND MarkupedPrice <= '" . $this->db->escape($data['filter_price_max'])."'";
                    else if(empty($data['filter_price_max']))
                        $sql .= " AND MarkupedPrice >= '" . $this->db->escape($data['filter_price_min']) ."'";
                    else
                        $sql .= " AND MarkupedPrice <= '" . $this->db->escape($data['filter_price_max']) . "' AND MarkupedPrice >= '" . $this->db->escape($data['filter_price_min']) ."'";
                }  

                if (!empty($data['filter_Tprice_min'] ) || !empty($data['filter_Tprice_max'] )) {
                        if(empty($data['filter_Tprice_min']))
                            $sql .= " AND MarkupedPrice <= '" . $this->db->escape($data['filter_Tprice_max'])."'";
                        else if(empty($data['filter_Tprice_max']))
                            $sql .= " AND MarkupedPrice >= '" . $this->db->escape($data['filter_Tprice_min']) ."'";
                        else
                            $sql .= " AND MarkupedPrice <= '" . $this->db->escape($data['filter_Tprice_max']) . "' AND MarkupedPrice >= '" . $this->db->escape($data['filter_Tprice_min']) ."'";
                } 

                if (!empty($data['filter_ct_min'] ) || !empty($data['filter_ct_max'] )) {
                        if(empty($data['filter_ct_min']))
                            $sql .= " AND Ct <= '" . $this->db->escape($data['filter_ct_max'])."'";
                        else if(empty($data['filter_ct_max']))
                            $sql .= " AND Ct >= '" . $this->db->escape($data['filter_ct_min']) ."'";
                        else
                            $sql .= " AND Ct <= '" . $this->db->escape($data['filter_ct_max']) . "' AND Ct >= '" . $this->db->escape($data['filter_ct_min']) ."'";
                }               
                
                if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
                    if($data['filter_status']=='1')
                    {
                       $sql .= " AND ID NOT IN(SELECT diamond_id FROM " . DB_PREFIX . "order_diamond)";
                    }
                    else if($data['filter_status']=='2')
                    {
                       $sql .= " AND ID IN(SELECT diamond_id FROM " . DB_PREFIX . "order_diamond)";
                    }
                }  
		
		$query = $this->db->query($sql);
		
		return $query->row['total'];
	}
        public function getDiamondStatus($diamond_id) {
                $query = $this->db->query("SELECT diamond_id FROM " . DB_PREFIX . "order_diamond WHERE diamond_id = '" . (int)$diamond_id . "'");
                return $query->num_rows; 
        }        
	public function getDiamonds($data = array()) {
		if ($data) {
                    
                        $sql = "SELECT * from (
                        SELECT  v.*, ROUND( REPLACE( v.TotalPrice,  ',',  '' ) * IFNULL( cm.MULTIPLY, 1 ) ) AS MarkupedPrice
                        FROM  `" . DB_PREFIX . "v_joyce` AS v , `" . DB_PREFIX . "caratmargin` AS cm WHERE cm.SHAPE = v.Shape
                        AND (
                        v.Ct
                        BETWEEN cm.START_CARAT
                        AND cm.FINISH_CARAT
                        )
                        ) as vj ," . DB_PREFIX . "shape as s WHERE LCASE(vj.Shape)=LCASE(s.shape)	
                        ";                    
                        //$sql = "SELECT * FROM " . DB_PREFIX . "v_joyce vj," . DB_PREFIX . "shape s WHERE LCASE(vj.Shape)=LCASE(s.shape)";
                        //$sql.=" AND vj.Certno IS NOT NULL AND vj.Certno!='' AND vj.Shape IS NOT NULL AND vj.Shape!='' AND vj.Color IS NOT NULL AND vj.Color!='' AND vj.Purity IS NOT NULL AND vj.Purity!='' AND vj.cut IS NOT NULL AND vj.cut!='' AND vj.Sym IS NOT NULL AND vj.Sym!='' AND vj.Pol IS NOT NULL AND vj.Pol!='' AND vj.Fluo IS NOT NULL AND vj.Fluo!='' AND vj.Fluo!='NONE' AND vj.Ct IS NOT NULL AND vj.Ct!='' AND vj.TotalPrice IS NOT NULL AND vj.TotalPrice!='' AND vj.Total_markup IS NOT NULL AND vj.Total_markup!=''";
                       	$sql.=" AND vj.Certno IS NOT NULL AND vj.Certno!=''";	 			
                        if (!empty($data['filter_certNo'])) {
                                $sql .= " AND LCASE(vj.Certno) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_certNo'])) . "%'";
                        }

                        if (!empty($data['filter_shape'])) {
                                $sql .= " AND LCASE(vj.Shape) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_shape'])) . "%'";
                        }

                        if (!empty($data['filter_color'])) {
                                $sql .= " AND LCASE(vj.Color) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_color'])) . "%'";
                        }

                        if (!empty($data['filter_purity'])) {
                                $sql .= " AND ((LCASE(vj.Purity) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_purity'])) . "%') OR (LCASE(vj.Clar) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_purity'])) . "%')) ";
                        }

                        if (!empty($data['filter_cut'])) {
                                $sql .= " AND LCASE(vj.Cut) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_cut'])) . "%'";
                        } 
                        
                        if (!empty($data['filter_sym'])) {
                                $sql .= " AND LCASE(vj.Sym) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_sym'])) . "%'";
                        }                 

                        if (!empty($data['filter_pol'])) {
                                $sql .= " AND LCASE(vj.Pol) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_pol'])) . "%'";
                        } 

                        if (!empty($data['filter_fluo'])) {
                                $sql .= " AND LCASE(vj.Fluo) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_fluo'])) . "%'";
                        }  
                        
                        if (!empty($data['filter_source'])) {
                                $sql .= " AND LCASE(vj.Source) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_source'])) . "%'";
                        }                        

                        /*if (!empty($data['filter_ct'])) {
                                $sql .= " AND LCASE(Ct) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_ct'])) . "%'";
                        }*/                

                        if (!empty($data['filter_price_min'] ) || !empty($data['filter_price_max'] )) {
                                if(empty($data['filter_price_min']))
                                    $sql .= " AND vj.MarkupedPrice <= '" . $this->db->escape($data['filter_price_max'])."'";
                                else if(empty($data['filter_price_max']))
                                    $sql .= " AND vj.MarkupedPrice >= '" . $this->db->escape($data['filter_price_min']) ."'";
                                else
                                    $sql .= " AND vj.MarkupedPrice <= '" . $this->db->escape($data['filter_price_max']) . "' AND vj.MarkupedPrice >= '" . $this->db->escape($data['filter_price_min']) ."'";
			}  
                        
                        if (!empty($data['filter_Tprice_min'] ) || !empty($data['filter_Tprice_max'] )) {
                                if(empty($data['filter_Tprice_min']))
                                    $sql .= " AND vj.MarkupedPrice <= '" . $this->db->escape($data['filter_Tprice_max'])."'";
                                else if(empty($data['filter_Tprice_max']))
                                    $sql .= " AND vj.MarkupedPrice >= '" . $this->db->escape($data['filter_Tprice_min']) ."'";
                                else
                                    $sql .= " AND vj.MarkupedPrice <= '" . $this->db->escape($data['filter_Tprice_max']) . "' AND vj.MarkupedPrice >= '" . $this->db->escape($data['filter_Tprice_min']) ."'";
			} 
                        
                        if (!empty($data['filter_ct_min'] ) || !empty($data['filter_ct_max'] )) {
                                if(empty($data['filter_ct_min']))
                                    $sql .= " AND vj.Ct <= '" . $this->db->escape($data['filter_ct_max'])."'";
                                else if(empty($data['filter_ct_max']))
                                    $sql .= " AND vj.Ct >= '" . $this->db->escape($data['filter_ct_min']) ."'";
                                else
                                    $sql .= " AND vj.Ct <= '" . $this->db->escape($data['filter_ct_max']) . "' AND vj.Ct >= '" . $this->db->escape($data['filter_ct_min']) ."'";
			}                      
                        
                        if (isset($data['filter_status']) && !is_null($data['filter_status'])) {
                            if($data['filter_status']=='1')
                            {
                            $sql .= " AND vj.ID NOT IN(SELECT diamond_id FROM " . DB_PREFIX . "order_diamond)";
                            }
                            else if($data['filter_status']=='2')
                            {
                            $sql .= " AND vj.ID IN(SELECT diamond_id FROM " . DB_PREFIX . "order_diamond)";
                            }
                        }  

 			if (isset($data['start']) || isset($data['limit'])) {
				if ($data['start'] < 0) {
					$data['start'] = 0;
				}				

				if ($data['limit'] < 1) {
					$data['limit'] = 20;
				}	
			
				$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
			}                       
                        
		} else {

                        $sql = "SELECT * from (
                        SELECT  v.*, ROUND( REPLACE( v.TotalPrice,  ',',  '' ) * IFNULL( cm.MULTIPLY, 1 ) ) AS MarkupedPrice
                        FROM  `" . DB_PREFIX . "v_joyce` AS v , `" . DB_PREFIX . "caratmargin` AS cm WHERE cm.SHAPE = v.Shape
                        AND (
                        v.Ct
                        BETWEEN cm.START_CARAT
                        AND cm.FINISH_CARAT
                        )
                        ) as p	
                        ";  
		}
                $query = $this->db->query($sql);
                return $query->rows;
	}
        public function getDiamondShapes() {
            $query = $this->db->query("SELECT DISTINCT shape FROM " . DB_PREFIX . "shape ORDER BY shapeid+0"); 
            return $query->rows;
        }
}
?>