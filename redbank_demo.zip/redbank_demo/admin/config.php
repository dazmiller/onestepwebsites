<?php
// HTTP
define('HTTP_SERVER', 'http://onestep.cloudapp.net/redbank_demo/admin/');
define('HTTP_CATALOG', 'http://onestep.cloudapp.net/redbank_demo/');
define('HTTP_IMAGE', 'http://onestep.cloudapp.net/redbank_demo/image/');

// HTTPS
define('HTTPS_SERVER', 'http://onestep.cloudapp.net/redbank_demo/admin/');
define('HTTPS_CATALOG', 'http://onestep.cloudapp.net/redbank_demo/');
define('HTTPS_IMAGE', 'http://onestep.cloudapp.net/redbank_demo/image/');

// DIR
define('DIR_APPLICATION', 'E:\websites\redbank_demo\admin\\');
define('DIR_SYSTEM', 'E:\websites\redbank_demo\system\\');
define('DIR_DATABASE', 'E:\websites\redbank_demo\system\database\\');
define('DIR_LANGUAGE', 'E:\websites\redbank_demo\admin\language\\');
define('DIR_TEMPLATE', 'E:\websites\redbank_demo\admin\view\template\\');
define('DIR_CONFIG', 'E:\websites\redbank_demo\system\config\\');
define('DIR_IMAGE', 'E:\websites\redbank_demo\image\\');
define('DIR_CACHE', 'E:\websites\redbank_demo\system\cache\\');
define('DIR_DOWNLOAD', 'E:\websites\redbank_demo\download\\');
define('DIR_LOGS', 'E:\websites\redbank_demo\system\logs\\');
define('DIR_CATALOG', 'E:\websites\redbank_demo\catalog\\');

// DB
define('DB_DRIVER', 'mysql');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');
define('DB_DATABASE', 'redbank');
define('DB_PREFIX', '');
?>