<?php
class ControllerSaleWholeSaleEnquiries extends Controller {
	private $error = array();

  	public function index() {
		$this->load->language('sale/wholesale_enquiries');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('sale/wholesale_enquiries');

    	$this->getList();
  	}
  	public function delete() {
		$this->load->language('sale/wholesale_enquiries');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('sale/wholesale_enquiries');

    	        if (isset($this->request->post['selected']) && ($this->validateDelete())) {
			foreach ($this->request->post['selected'] as $enquiry_id) {
				$this->model_sale_wholesale_enquiries->deleteEnquiry($enquiry_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
                        
                        if (isset($this->request->get['filter_enquiry_id'])) {
                                $url .= '&filter_enquiry_id=' . $this->request->get['filter_enquiry_id'];
                        }

                        if (isset($this->request->get['filter_customer'])) {
                                $url .= '&filter_customer=' . $this->request->get['filter_customer'];
                        }

                        if (isset($this->request->get['filter_enquiry_status_id'])) {
                                $url .= '&filter_enquiry_status_id=' . $this->request->get['filter_enquiry_status_id'];
                        }

                        if (isset($this->request->get['filter_date_added'])) {
                                $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
                        }

                        if (isset($this->request->get['filter_date_modified'])) {
                                $url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
                        }
												
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->redirect($this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . $url, 'SSL'));
    	}

    	$this->getList();
  	}	
     	private function validateDelete() {
    	if (!$this->user->hasPermission('modify', 'sale/wholesale_enquiries')) {
			$this->error['warning'] = $this->language->get('error_permission');
    	}

		if (!$this->error) {
	  		return true;
		} else {
	  		return false;
		}
  	}	
  	private function getList() {
	
		if (isset($this->request->get['filter_enquiry_id'])) {
			$filter_enquiry_id = $this->request->get['filter_enquiry_id'];
		} else {
			$filter_enquiry_id = null;
		}
		
		if (isset($this->request->get['filter_customer'])) {
			$filter_customer = $this->request->get['filter_customer'];
		} else {
			$filter_customer = null;
		}
		
		/*if (isset($this->request->get['filter_address'])) {
			$filter_address = $this->request->get['filter_address'];
		} else {
			$filter_address = null;
		}*/
                
		if (isset($this->request->get['filter_enquiry_status_id'])) {
			$filter_enquiry_status_id = $this->request->get['filter_enquiry_status_id'];
		} else {
			$filter_enquiry_status_id = null;
		}   
		
		if (isset($this->request->get['filter_date_added'])) {
			$filter_date_added = $this->request->get['filter_date_added'];
		} else {
			$filter_date_added = null;
		}
		
		if (isset($this->request->get['filter_date_modified'])) {
			$filter_date_modified = $this->request->get['filter_date_modified'];
		} else {
			$filter_date_modified = null;
		}
		
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'e.enquiry_id';
		}
		
  		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}
		
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
               
		$url = '';

		if (isset($this->request->get['filter_enquiry_id'])) {
			$url .= '&filter_enquiry_id=' . $this->request->get['filter_enquiry_id'];
		}
		
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . $this->request->get['filter_customer'];
		}
											
		if (isset($this->request->get['filter_enquiry_status_id'])) {
			$url .= '&filter_enquiry_status_id=' . $this->request->get['filter_enquiry_status_id'];
		}
					
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}
		
		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}
		
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}                
                
		$this->data['breadcrumbs'] = array();

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . $url, 'SSL'),
      		'separator' => ' :: '
   		);

                $this->data['delete'] = $this->url->link('sale/wholesale_enquiries/delete', 'token=' . $this->session->data['token'] . $url, 'SSL');

		$this->data['enquiries'] = array();

		$data = array(
			'filter_enquiry_id'      => $filter_enquiry_id,
			'filter_customer'	 => $filter_customer,
			//'filter_address'         => $filter_address,
                        'filter_enquiry_status_id' => $filter_enquiry_status_id,
			'filter_date_added'      => $filter_date_added,
			'filter_date_modified'   => $filter_date_modified,
			'sort'                   => $sort,
			'order'                  => $order,
			'start'                  => ($page - 1) * $this->config->get('config_admin_limit'),
			'limit'                  => $this->config->get('config_admin_limit')
		);

		$enquiry_total = $this->model_sale_wholesale_enquiries->getTotalEnquiries($data);
		$results = $this->model_sale_wholesale_enquiries->getWholeSaleEnquiries($data);

    	        foreach ($results as $result) {
			$action = array();
			$this->data['sort']="";	
			$action[] = array(
				'text' => $this->language->get('text_view'),
				'href' => $this->url->link('sale/wholesale_enquiries/info', 'token=' . $this->session->data['token'] . '&enquiry_id=' . $result['enquiry_id'] . $url, 'SSL')
			);

			$this->data['enquiries'][] = array(
				'enquiry_id'    => $result['enquiry_id'],
				'customer'      => $result['customer'],
				'address'      => $result['address'],
                                'status'      => $result['status'],
                                'order_id'      => $result['order_id'],
                                'order_href'   => $this->url->link('sale/order/info', 'token=' . $this->session->data['token'] . '&order_id=' . $result['order_id'], 'SSL'),
				'date_added'    => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'date_modified' => date($this->language->get('date_format_short'), strtotime($result['date_modified'])),
				'selected'      => isset($this->request->post['selected']) && in_array($result['enquiry_id'], $this->request->post['selected']),
				'action'        => $action
			);
		}

		$this->data['heading_title'] = $this->language->get('heading_title');

		$this->data['text_no_results'] = $this->language->get('text_no_results');
                $this->data['text_abandoned_enquiries'] = $this->language->get('text_abandoned_enquiries');
		$this->data['column_enquiry_id'] = $this->language->get('column_enquiry_id');
    	        $this->data['column_customer'] = $this->language->get('column_customer');
		$this->data['column_address'] = $this->language->get('column_address');
                $this->data['column_status'] = $this->language->get('column_status');
		$this->data['column_date_added'] = $this->language->get('column_date_added');
		$this->data['column_date_modified'] = $this->language->get('column_date_modified');
		$this->data['column_action'] = $this->language->get('column_action');

	        $this->data['button_add_to_order'] = $this->language->get('entry_button_add_to_order');
		$this->data['button_delete'] = $this->language->get('button_delete');
		$this->data['button_filter'] = $this->language->get('button_filter');

 		$this->load->model('localisation/enquiry_status');

    	        $this->data['enquiry_statuses'] = $this->model_localisation_enquiry_status->getEnquiryStatuses();               
                
                
		$this->data['token'] = $this->session->data['token'];

		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}

		$url = '';

		if (isset($this->request->get['filter_enquiry_id'])) {
			$url .= '&filter_enquiry_id=' . $this->request->get['filter_enquiry_id'];
		}
		
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . $this->request->get['filter_customer'];
		}
											
		if (isset($this->request->get['filter_enquiry_status_id'])) {
			$url .= '&filter_enquiry_status_id=' . $this->request->get['filter_enquiry_status_id'];
		}
					
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}
		
		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if ($order == 'ASC') {
			$url .= '&order=' .  'DESC';
		} else {
			$url .= '&order=' .  'ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$this->data['sort_enquiry'] = $this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . '&sort=e.enquiry_id' . $url, 'SSL');
		$this->data['sort_customer'] = $this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . '&sort=customer' . $url, 'SSL');
		$this->data['sort_status'] = $this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . '&sort=e.enquiry_status_id' . $url, 'SSL');
		$this->data['sort_date_added'] = $this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . '&sort=e.date_added' . $url, 'SSL');
		$this->data['sort_date_modified'] = $this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . '&sort=e.date_modified' . $url, 'SSL');   

		$url = '';

		if (isset($this->request->get['filter_enquiry_id'])) {
			$url .= '&filter_enquiry_id=' . $this->request->get['filter_enquiry_id'];
		}
		
		if (isset($this->request->get['filter_customer'])) {
			$url .= '&filter_customer=' . $this->request->get['filter_customer'];
		}
											
		if (isset($this->request->get['filter_enquiry_status_id'])) {
			$url .= '&filter_enquiry_status_id=' . $this->request->get['filter_enquiry_status_id'];
		}
					
		if (isset($this->request->get['filter_date_added'])) {
			$url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
		}
		
		if (isset($this->request->get['filter_date_modified'])) {
			$url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $enquiry_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_admin_limit');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

		$this->data['pagination'] = $pagination->render();

		$this->data['filter_enquiry_id'] = $filter_enquiry_id;
		$this->data['filter_customer'] = $filter_customer;
		//$this->data['filter_address'] = $filter_address;
                $this->data['filter_enquiry_status_id'] = $filter_enquiry_status_id;
		$this->data['filter_date_added'] = $filter_date_added;
		$this->data['filter_date_modified'] = $filter_date_modified;
                
                $this->data['sort'] = $sort;
		$this->data['order'] = $order;

		$this->template = 'sale/wholesale_enquiries_list.tpl';
		$this->children = array(
			'common/header',
			'common/footer'
		);
		
		$this->response->setOutput($this->render());
  	}

	
        public function info() {

	      $this->load->model('sale/wholesale_enquiries');

		if (isset($this->request->get['enquiry_id'])) {
			$enquiry_id = $this->request->get['enquiry_id'];
		} else {
			$enquiry_id = 0;
		}
                       
		$enquiry_info = $this->model_sale_wholesale_enquiries->getWholeSaleEnquiry($enquiry_id);

                if ($enquiry_info) {
                    $this->load->language('sale/wholesale_enquiries');   
                    $this->document->setTitle($this->language->get('heading_title'));
                    $this->data['heading_title'] = $this->language->get('heading_title');    
                    $this->data['entry_button_add_to_order'] = $this->language->get('entry_button_add_to_order');
                    $this->data['entry_button_cancel'] = $this->language->get('entry_button_cancel');
                    $this->data['text_enquiry_id'] = $this->language->get('text_enquiry_id');
                    $this->data['text_customer_id'] = $this->language->get('text_customer_id');
                    $this->data['text_customer_name'] = $this->language->get('text_customer_name');
                    $this->data['text_customer_telephone'] = $this->language->get('text_customer_telephone');
                    $this->data['text_customer_email'] = $this->language->get('text_customer_email');
                    $this->data['text_customer_group'] = $this->language->get('text_customer_group');
                    $this->data['text_customer_shipping_address'] = $this->language->get('text_customer_shipping_address');
                    $this->data['text_billing_address'] = $this->language->get('text_billing_address');
                    $this->data['text_shipping_address'] = $this->language->get('text_shipping_address');                    
                    $this->data['text_ip_address'] = $this->language->get('text_ip_address');
                    $this->data['text_customer_additional_info'] = $this->language->get('text_customer_additional_info');
                    $this->data['text_product_name'] = $this->language->get('text_product_name');
                    $this->data['text_procduct_model'] = $this->language->get('text_procduct_model');                        
                    $this->data['text_product_unit_price'] = $this->language->get('text_product_unit_price');
                    $this->data['text_wholesale_unit_price'] = $this->language->get('text_wholesale_unit_price');					
                    $this->data['text_product_quantity'] = $this->language->get('text_product_quantity');
                    $this->data['text_available_quantity'] = $this->language->get('text_available_quantity');                    
                    $this->data['text_product_retail_total_price'] = $this->language->get('text_product_retail_total_price');
                    $this->data['text_product_wholesale_total_price'] = $this->language->get('text_product_wholesale_total_price');
                    $this->data['text_bargain_wholesale_price'] = $this->language->get('text_bargain_wholesale_price');
                    $this->data['text_shipping_price'] = $this->language->get('text_shipping_price');
                    $this->data['text_shipping_method'] = $this->language->get('text_shipping_method');
                    $this->data['text_enquiry_details'] = $this->language->get('text_enquiry_details');
                    $this->data['text_customer_personal_info'] = $this->language->get('text_customer_personal_info');
                    $this->data['text_product_wholesale_price'] = $this->language->get('text_product_wholesale_price');
                    
                    
                    $this->data['text_store_name'] = $this->language->get('text_store_name');
                    $this->data['text_store_url'] = $this->language->get('text_store_url');   
                    $this->data['text_business_type'] = $this->language->get('text_business_type');
                    $this->data['text_prod_interested'] = $this->language->get('text_prod_interested');
                    $this->data['text_estimated_amt'] = $this->language->get('text_estimated_amt');    
					$this->data['text_shipping_fee'] = $this->language->get('text_shipping_fee');  					
                    
                    $this->data['text_enquiry_status'] = $this->language->get('text_enquiry_status');    
                    $this->data['text_date_added'] = $this->language->get('text_date_added');      
                    $this->data['text_date_modified'] = $this->language->get('text_date_modified');                        
                    
	            $url = '';

                    if (isset($this->request->get['filter_enquiry_id'])) {
                            $url .= '&filter_enquiry_id=' . $this->request->get['filter_enquiry_id'];
                    }

                    if (isset($this->request->get['filter_customer'])) {
                            $url .= '&filter_customer=' . $this->request->get['filter_customer'];
                    }

                    if (isset($this->request->get['filter_enquiry_status_id'])) {
                            $url .= '&filter_enquiry_status_id=' . $this->request->get['filter_enquiry_status_id'];
                    }

                    if (isset($this->request->get['filter_date_added'])) {
                            $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
                    }

                    if (isset($this->request->get['filter_date_modified'])) {
                            $url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
                    }

                    if (isset($this->request->get['sort'])) {
                            $url .= '&sort=' . $this->request->get['sort'];
                    }

                    if (isset($this->request->get['order'])) {
                            $url .= '&order=' . $this->request->get['order'];
                    }

                    if (isset($this->request->get['page'])) {
                            $url .= '&page=' . $this->request->get['page'];
                    }

                    
                    $this->data['breadcrumbs'] = array();

                    $this->data['breadcrumbs'][] = array(
                            'text'      => $this->language->get('text_home'),
                            'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
                            'separator' => false
                    );

                    $this->data['breadcrumbs'][] = array(
                            'text'      => $this->language->get('heading_title'),
                            'href'      => $this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'], 'SSL'),				
                            'separator' => ' :: '
                    );

                    $this->data['action'] = $this->url->link('sale/wholesale_enquiries/insert', 'token=' . $this->session->data['token']. $url, 'SSL');   	                        
                    $this->data['cancel'] = $this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . $url, 'SSL');
                    
                    //ENQUIRY DETAILS
                    $this->data['enquiry_id'] = $enquiry_info['enquiry_id'];
                    $this->data['status'] = $enquiry_info['status'];
                    $this->data['order_id'] = $enquiry_info['order_id'];
                    $this->data['order_href'] =$this->url->link('sale/order/info', 'token=' . $this->session->data['token'] . '&order_id=' . $enquiry_info['order_id'], 'SSL');                              
                    $this->data['store_name'] = $enquiry_info['store_name'];
		    $this->data['store_url'] = $enquiry_info['store_url'];
                    $this->data['ip'] = $enquiry_info['ip'];
                    $this->data['date_added'] = date($this->language->get('date_format_short'), strtotime($enquiry_info['date_added']));
                    $this->data['date_modified'] = date($this->language->get('date_format_short'), strtotime($enquiry_info['date_modified'])); 
                  
                    //CUSTOMER PERSONAL DETAILS
                    $this->data['customer_name'] = $enquiry_info['customer'];
                  
                    $this->load->model('sale/customer_group');
                    $customer_group_info = $this->model_sale_customer_group->getCustomerGroup($enquiry_info['customer_group_id']);                  
                    if ($customer_group_info) {
                         $this->data['customer_group'] = $customer_group_info['name'];
                    } else {
                         $this->data['customer_group'] = '';
                    }
                    $this->data['telephone'] = $enquiry_info['telephone'];
                    $this->data['email'] = $enquiry_info['email']; 
                    $this->data['billing_address'] = $enquiry_info['billing_address'];
                    $this->data['shipping_address'] = $enquiry_info['shipping_address'];
                  
		    $this->data['business_type'] = $enquiry_info['business_type'];   
                    $this->data['prod_interested'] = $enquiry_info['prod_interested'];  
                    $this->data['estimated_amt'] = $this->currency->format($enquiry_info['estimated_amt'], $enquiry_info['currency_code'], $enquiry_info['currency_value']);
                    
                    $this->data['products'] = array();
                    $hasStock=true;
                    foreach ($enquiry_info['products'] as $product) {
                         
                           if(!$product['stock']) {
                             $hasStock=false; 
                           }
                        
                            $this->data['products'][] = array(
                                'enquiry_product_id' => $product['enquiry_product_id'],
                                'name'               => $product['name'],
                                'model'              => $product['model'],
                                'availableQty'       => $product['availableQty'],
                                'quantity'           => $product['quantity'],
                                'stock'              => $product['stock'],
				'wholesale_unit_price'  => $this->currency->formatReturnNumONLY($product['product_wholesale_price'], $enquiry_info['currency_code'], $enquiry_info['currency_value']),
                                'total_price'        => $this->currency->formatReturnNumONLY(($product['quantity']*$product['product_wholesale_price']), $enquiry_info['currency_code'], $enquiry_info['currency_value']),
                                'price'              => $this->currency->format($product['price'], $enquiry_info['currency_code'], $enquiry_info['currency_value']),
                                'product_wholesale_price'  => $this->currency->format($product['product_wholesale_price'], $enquiry_info['currency_code'], $enquiry_info['currency_value']),
                                'total'              => $this->currency->format($product['total'], $enquiry_info['currency_code'], $enquiry_info['currency_value'])
                            );
                    } 

                    if (!$hasStock && (!$this->config->get('config_stock_checkout') || $this->config->get('config_stock_warning'))) {
                          $this->data['error_warning'] = $this->language->get('error_stock');
                    } elseif (isset($this->session->data['error'])) {
                            $this->data['error_warning'] = $this->session->data['error'];

                            unset($this->session->data['error']);			
                    } else {
                            $this->data['error_warning'] = '';
                    }                
                    
                    $this->template = 'sale/wholesale_enquiries_info.tpl';
                    $this->children = array(
                            'common/header',
                            'common/footer'
                    );

                    $this->response->setOutput($this->render());
                 } else {
			$this->load->language('error/not_found');

			$this->document->setTitle($this->language->get('heading_title'));

			$this->data['heading_title'] = $this->language->get('heading_title');

			$this->data['text_not_found'] = $this->language->get('text_not_found');

			$this->data['breadcrumbs'] = array();

			$this->data['breadcrumbs'][] = array(
				'text'      => $this->language->get('text_home'),
				'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
				'separator' => false
			);

			$this->data['breadcrumbs'][] = array(
				'text'      => $this->language->get('heading_title'),
				'href'      => $this->url->link('error/not_found', 'token=' . $this->session->data['token'], 'SSL'),
				'separator' => ' :: '
			);
		      
			$this->template = 'error/not_found.tpl';
			$this->children = array(
				'common/header',
				'common/footer'
			);
		
			$this->response->setOutput($this->render());
		}	
	}
        
    

   public function insert(){
        $url="";
        $this->load->model('sale/wholesale_enquiries');
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
           $url = '';

            if (isset($this->request->get['filter_enquiry_id'])) {
                    $url .= '&filter_enquiry_id=' . $this->request->get['filter_enquiry_id'];
            }

            if (isset($this->request->get['filter_customer'])) {
                    $url .= '&filter_customer=' . $this->request->get['filter_customer'];
            }

            if (isset($this->request->get['filter_enquiry_status_id'])) {
                    $url .= '&filter_enquiry_status_id=' . $this->request->get['filter_enquiry_status_id'];
            }

            if (isset($this->request->get['filter_date_added'])) {
                    $url .= '&filter_date_added=' . $this->request->get['filter_date_added'];
            }

            if (isset($this->request->get['filter_date_modified'])) {
                    $url .= '&filter_date_modified=' . $this->request->get['filter_date_modified'];
            }

            if (isset($this->request->get['sort'])) {
                    $url .= '&sort=' . $this->request->get['sort'];
            }

            if (isset($this->request->get['order'])) {
                    $url .= '&order=' . $this->request->get['order'];
            }
            
            if (isset($this->request->get['page'])) {
                    $url .= '&page=' . $this->request->get['page'];
            }    
			
            $hasStock = true;
            foreach ($this->request->post['wholesale_product'] as $product) {
                if((!(float)$product['availableQty']) || ((float)$product['availableQty']<(float)$product['quantity'])) {
                            $hasStock = false;
                }
            }
            
            if (!$hasStock && !$this->config->get('config_stock_checkout')) {   
		     	$this->load->language('sale/wholesale_enquiries');
			    $this->session->data['error']=$this->language->get('error_stock'); 
                $this->redirect($this->url->link('sale/wholesale_enquiries/info', 'token=' . $this->session->data['token'] . '&enquiry_id=' . $this->request->post['enquiry_id']. $url, 'SSL'));
            }
            else {
                $this->model_sale_wholesale_enquiries->addEnquiryToOrder($this->request->post);        
                $this->redirect($this->url->link('sale/wholesale_enquiries', 'token=' . $this->session->data['token'] . $url, 'SSL'));               
            }
       }
   } 
   
   public function validateForm() {return true;}
}
?>