<?php
// Heading
$_['heading_title']      = 'eWAY Australia';

// Text
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified your eWAY module details!';
$_['text_eway_au']   = '<a onclick="window.open(\'http://www.eway.com.au/\');"><img src="view/image/payment/eway_au.jpg" alt="eWay AU" title="eWay AU" style="border: 1px solid #cccccc;" /></a>';

// Entry
$_['entry_test']         = 'Test mode:';
$_['entry_order_status'] = 'Order status:';

$_['entry_geo_zone']     = 'Geo zone:';

$_['entry_status']       = 'Status:';
$_['entry_customerid']	 = 'eWAY customer ID:';
$_['entry_sort_order']   = 'Sort order:';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify the eWAY payment module';
$_['error_customername'] = 'eWAY username is required!';
$_['error_customerid']	 = 'eWAY customer ID is required!';


//Help hints
$_['help_testmode']   = '<span style="font-size:11px; color:#999">You can set to go to testing mode here.</span>';
$_['help_customerid']   = '<span style="font-size:11px; color:#999">Your unique eWAY customer ID assigned to you When you join eWAY.</span>';
$_['help_username']   = '<span style="font-size:11px; color:#999">Your eWAY username registered when you join eWay.</span>';
$_['help_returnurl']   = '<span style="font-size:11px; color:#999">Domain URL that redirects from eWAY after the transaction success.<br />
<span style="color:#F00">Don`t change it if you don`t know what you are doing.</span></span>';
$_['help_cancelurl']   = '<span style="font-size:11px; color:#999">Domain URL that redirects from eWAY after the transaction fails or cancelled.<br />
<span style="color:#F00">Don`t change it if you don`t know what you are doing.</span></span>';
$_['help_pagetitle']   = '<span style="font-size:11px; color:#999">Page title to be displaying in the eWAY shared page.</span>';
$_['help_pagedescription']   = '<span style="font-size:11px; color:#999">Page description to be displaying in the eWay shared page.</span>';
$_['help_pagefooter']   = '<span style="font-size:11px; color:#999">Page footer to be displaying in the eWAY shared page.</span>';
$_['help_companyname']   = '<span style="font-size:11px; color:#999">Company or store name to be displaying in the eWAY shared page.</span>';
$_['help_companylogo']   = '<span style="font-size:11px; color:#999">Give URL of the Company LOGO to be displaying in the eWAY shared page.</span>';
$_['help_companybanner']   = '<span style="font-size:11px; color:#999">Give URL of the Company banner to be displaying in the eWAY shared page.</span>';
$_['help_modifycustomer']   = '<span style="font-size:11px; color:#999">Control the customer details on the eWAY shared page.</span>';
$_['help_ewaylanguage']   = '<span style="font-size:11px; color:#999">Choose Language to be display in the eWAY shared page.</span>';
$_['help_ewaystatus']   = '<span style="font-size:11px; color:#999">Do you want to authorize payment through eWAY Payment?</span>';
$_['help_setorderstatus']   = '<span style="font-size:11px; color:#999">Set the status of orders made with this payment module to this value.</span>';
$_['help_sort_order']   = '<span style="font-size:11px; color:#999">Set the display order in relation to other payment options. The higher the number the "heavier" it is.</span>';


?>