<?php
// Heading
$_['heading_title']           = 'Enquiries';

// Text
$_['text_success']            = 'Success: You have modified orders!';
$_['text_enquiry_id']         = 'Enquiry ID:';
$_['text_customer_id']        = 'Customer ID:';
$_['text_customer_name']        = 'Customer Name:';
$_['text_customer_telephone'] = 'Customer Telephone:';
$_['text_customer_email']     = 'Customer Email:';
$_['text_customer_group']     = 'Customer Group:';
$_['text_customer_shipping_address'] = 'Customer Address:';
$_['text_billing_address']  = 'Payment Address:';
$_['text_shipping_address'] = 'Shipping Address:';
$_['text_ip_address']         = 'IP Address:';
$_['text_customer_additional_info']  = 'Customer Additional Information:';
$_['text_product_name']       = 'Product Name';
$_['text_procduct_model']     = 'Model';
$_['text_product_unit_price']= 'Retail Unit Price';
$_['text_wholesale_unit_price']= 'Wholesale Unit Price';
$_['text_product_wholesale_price']= 'Product Wholesale Price';
$_['text_product_quantity']       = 'Quantity';
$_['text_available_quantity']       = 'Available Quantity';
$_['text_product_retail_total_price']     = 'Retail Total Price';
$_['text_product_wholesale_total_price']= 'Wholesale Total Price';
$_['text_bargain_wholesale_price']     = 'Bargain Wholesale Price';
$_['text_shipping_price']= 'Shipping Price:';
$_['text_shipping_method']= 'Shipping Method:';
$_['text_abandoned_enquiries']   = 'Abandoned Enquiries';
$_['text_enquiry_details']= 'Enquiry Details';
$_['text_customer_personal_info']= 'Customer\'s Personal Details';
$_['text_store_name']         = 'Store Name:';
$_['text_store_url']          = 'Store Url:';
$_['text_business_type']          = 'Business Type:';
$_['text_prod_interested']          = 'Product Interested:';
$_['text_estimated_amt']          = 'Estimated Amount:';
$_['text_enquiry_status']       = 'Enquiry Status:';
$_['text_date_added']         = 'Date Added:';
$_['text_date_modified']      = 'Date Modified:';
$_['text_shipping_fee']      = 'Shipping Fee';

$_['entry_button_add_to_order']= 'Add To Order';
$_['entry_button_cancel']= 'Cancel';

 
// Column
$_['column_enquiry_id']         = 'Enquiry ID';
$_['column_customer']         = 'Customer';
$_['column_address']         = 'Address';
$_['column_status']           = 'Status';
$_['column_date_added']       = 'Date Added';
$_['column_date_modified']    = 'Date Modified';
$_['column_total']            = 'Total';
$_['column_product']          = 'Product';
$_['column_model']            = 'Model';
$_['column_quantity']         = 'Quantity';
$_['column_price']            = 'Unit Price';
$_['column_download']         = 'Download Name';
$_['column_filename']         = 'Filename';
$_['column_remaining']        = 'Remaining Downloads';
$_['column_comment']          = 'Comment';
$_['column_notify']           = 'Customer Notified';
$_['column_action']           = 'Action';

// Error
$_['error_stock']     = 'Products marked with *** are not available in the desired quantity or not in stock!';
$_['error_permission']        = 'Warning: You do not have permission to modify orders!';
$_['error_firstname']         = 'First Name must be between 1 and 32 characters!';
$_['error_lastname']          = 'Last Name must be between 1 and 32 characters!';
$_['error_email']             = 'E-Mail Address does not appear to be valid!';
$_['error_telephone']         = 'Telephone must be between 3 and 32 characters!';
$_['error_password']          = 'Password must be between 3 and 20 characters!';
$_['error_confirm']           = 'Password and password confirmation do not match!';
$_['error_address_1']         = 'Address 1 must be between 3 and 128 characters!';
$_['error_city']              = 'City must be between 3 and 128 characters!';
$_['error_postcode']          = 'Postcode must be between 2 and 10 characters for this country!';
$_['error_country']           = 'Please select a country!';
$_['error_zone']              = 'Please select a region / state!';
$_['error_upload']            = 'Upload required!';
$_['error_filename']          = 'Filename must be between 3 and 128 characters!';
$_['error_filetype']          = 'Invalid file type!';
$_['error_action']            = 'Warning: Could not complete this action!';
?>