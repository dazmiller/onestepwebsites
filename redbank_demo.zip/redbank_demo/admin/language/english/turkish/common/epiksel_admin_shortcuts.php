<?php
/* Developer: Ekrem KAYA
Web Page: www.e-piksel.com */

// E-Menu
$_['text_emenu_add_product']	= 'Ürün Ekle';
$_['text_emenu_products']		= 'Ürünler';
$_['text_emenu_add_category']	= 'Kategori Ekle';
$_['text_emenu_categories']		= 'Kategoriler';
$_['text_emenu_options']		= 'Seçenekler';
$_['text_emenu_manufacturer']	= 'Üreticiler';
$_['text_emenu_information']	= 'Bilgi Sayfaları';
$_['text_emenu_reviews']		= 'Yorumlar';
$_['text_emenu_orders']			= 'Siparişler';
$_['text_emenu_returns']		= 'Ürün İadeleri';
$_['text_emenu_customers']		= 'Müşteriler';
$_['text_emenu_coupons']		= 'Kuponlar';
$_['text_emenu_mail']			= 'Toplu E-Posta';
$_['text_emenu_settings']		= 'Ayarlar';
$_['text_emenu_purchased']		= 'Satılan';
$_['text_emenu_backup_restore']	= 'Yedekle';
?>