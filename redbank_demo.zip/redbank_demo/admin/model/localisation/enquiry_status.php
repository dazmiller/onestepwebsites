<?php 
class ModelLocalisationEnquiryStatus extends Model {
	public function addEnquiryStatus($data) {
		foreach ($data['enquiry_status'] as $language_id => $value) {
			if (isset($enquiry_status_id)) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "enquiry_status SET enquiry_status_id = '" . (int)$enquiry_status_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "'");
			} else {
				$this->db->query("INSERT INTO " . DB_PREFIX . "enquiry_status SET language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "'");
				
				$enquiry_status_id = $this->db->getLastId();
			}
		}
		
		$this->cache->delete('enquiry_status');
	}

	public function editEnquiryStatus($enquiry_status_id, $data) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "enquiry_status WHERE enquiry_status_id = '" . (int)$enquiry_status_id . "'");

		foreach ($data['enquiry_status'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "enquiry_status SET enquiry_status_id = '" . (int)$enquiry_status_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "'");
		}
				
		$this->cache->delete('enquiry_status');
	}
	
	public function deleteEnquiryStatus($enquiry_status_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "enquiry_status WHERE enquiry_status_id = '" . (int)$enquiry_status_id . "'");
	
		$this->cache->delete('enquiry_status');
	}
		
	public function getEnquiryStatus($enquiry_status_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "enquiry_status WHERE enquiry_status_id = '" . (int)$enquiry_status_id . "' AND language_id = '" . (int)$this->config->get('config_language_id') . "'");
		
		return $query->row;
	}
		
	public function getEnquiryStatuses($data = array()) {
      	if ($data) {
			$sql = "SELECT * FROM " . DB_PREFIX . "enquiry_status WHERE language_id = '" . (int)$this->config->get('config_language_id') . "'";			
			$sql .= " ORDER BY name";	
			
			if (isset($data['enquiry']) && ($data['enquiry'] == 'DESC')) {
				$sql .= " DESC";
			} else {
				$sql .= " ASC";
			}
			
			if (isset($data['start']) || isset($data['limit'])) {
				if ($data['start'] < 0) {
					$data['start'] = 0;
				}				

				if ($data['limit'] < 1) {
					$data['limit'] = 20;
				}	
			
				$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
			}	
			
			$query = $this->db->query($sql);
			
			return $query->rows;
		} else {
			$enquiry_status_data = $this->cache->get('enquiry_status.' . (int)$this->config->get('config_language_id'));
		
			if (!$enquiry_status_data) {
				$query = $this->db->query("SELECT enquiry_status_id, name FROM " . DB_PREFIX . "enquiry_status WHERE language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY name");
	
				$enquiry_status_data = $query->rows;
			
				$this->cache->set('enquiry_status.' . (int)$this->config->get('config_language_id'), $enquiry_status_data);
			}	
	
			return $enquiry_status_data;				
		}
	}
	
	public function getEnquiryStatusDescriptions($enquiry_status_id) {
		$enquiry_status_data = array();
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "enquiry_status WHERE enquiry_status_id = '" . (int)$enquiry_status_id . "'");
		
		foreach ($query->rows as $result) {
			$enquiry_status_data[$result['language_id']] = array('name' => $result['name']);
		}
		
		return $enquiry_status_data;
	}
	
	public function getTotalEnquiryStatuses() {
      	$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "enquiry_status WHERE language_id = '" . (int)$this->config->get('config_language_id') . "'");
		
		return $query->row['total'];
	}	
}
?>