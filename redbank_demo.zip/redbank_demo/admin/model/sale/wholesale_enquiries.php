<?php
class ModelSaleWholeSaleEnquiries extends Model {
   
	public function getWholeSaleEnquiry($enquiry_id) {
             
            $enquiries_query=$this->db->query("SELECT *, (SELECT os.name  FROM " . DB_PREFIX . "enquiry_status os  WHERE os.enquiry_status_id = e.enquiry_status_id  AND os.language_id = '" . (int)$this->config->get('config_language_id') . "') AS status,
                    CONCAT(e.firstname, ' ', e.lastname) AS customer, CONCAT(e.payment_firstname, ' ', e.payment_lastname,',<br>',e.payment_address_1,' ',e.payment_address_2,' ',e.payment_city,' - ',e.payment_postcode,', ',payment_country) AS 'billing_address', CONCAT(e.shipping_firstname, ' ', e.shipping_lastname,',<br>',e.shipping_address_1,' ',e.shipping_address_2,' ',e.shipping_city,' - ',e.shipping_postcode,', ',shipping_country) AS 'shipping_address'   FROM `" . DB_PREFIX . "enquiry` e WHERE e.enquiry_id = '" . (int)$enquiry_id . "'");
  
             if ($enquiries_query->num_rows) {
                 $enquiry_product_query = $this->db->query("SELECT ep.*,p.wholesale_price AS product_wholesale_price, p.quantity AS availableQty,IF((p.quantity>0 && p.quantity>=ep.quantity),1,0) AS stock FROM " . DB_PREFIX . "enquiry_product ep, " . DB_PREFIX . "product p WHERE ep.product_id=p.product_id AND ep.enquiry_id = '" . (int)$enquiry_id . "'");
                 
                 //$enquiry_product_query = $this->db->query("SELECT ep.*, (SELECT p.quantity FROM product p WHERE p.product_id=ep.product_id) AS availableQty FROM " . DB_PREFIX . "enquiry_product ep WHERE ep.enquiry_id = '" . (int)$enquiry_id . "'");
                 $enquiries_query->row['products']=$enquiry_product_query->rows;             
                 return $enquiries_query->row;
             }
             else {
                 return false;
             }
	}
	
	public function getWholeSaleEnquiries($data = array()) {
            
                $sql = "SELECT e.enquiry_id,e.order_id, CONCAT(e.firstname, ' ', e.lastname) AS customer, (SELECT os.name  FROM " . DB_PREFIX . "enquiry_status os  WHERE os.enquiry_status_id = e.enquiry_status_id  AND os.language_id = '" . (int)$this->config->get('config_language_id') . "') AS status, 
                   e.total,e.currency_code, e.currency_value, e.date_added, e.date_modified, CONCAT(e.payment_address_1,' ',e.payment_address_2,' ',e.payment_city,', ',(SELECT c.name FROM " . DB_PREFIX . "country c WHERE c.country_id=e.payment_country_id )) AS 'address'   FROM `" . DB_PREFIX . "enquiry` e";         

  		if (isset($data['filter_enquiry_status_id']) && !is_null($data['filter_enquiry_status_id'])) {
			$sql .= " WHERE e.enquiry_status_id = '" . (int)$data['filter_enquiry_status_id'] . "'";
		} else {
			$sql .= " WHERE e.enquiry_status_id > '0'";
		}
		if (!empty($data['filter_enquiry_id'])) {
			$sql .= " AND e.enquiry_id = '" . (int)$data['filter_enquiry_id'] . "'";
		}

		if (!empty($data['filter_customer'])) {
			$sql .= " AND LCASE(CONCAT(e.firstname, ' ', e.lastname)) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_customer'])) . "%'";
		}

		if (!empty($data['filter_date_added'])) {
			$sql .= " AND DATE(e.date_added) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
		}
                
		if (!empty($data['filter_date_modified'])) {
			$sql .= " AND DATE(e.date_modified) = DATE('" . $this->db->escape($data['filter_date_modified']) . "')";
		}

		$sort_data = array(
			'e.enquiry_id',
			'customer',
			'e.enquiry_status_id',
			'e.date_added',
			'e.date_modified',
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY e.enquiry_id";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}     
                
		$query = $this->db->query($sql);
	
		return $query->rows;
	
	
	}

        public function getTotalEnquiries($data = array()) {
               $sql = "SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "enquiry` e";

   		if (isset($data['filter_enquiry_status_id']) && !is_null($data['filter_enquiry_status_id'])) {
			$sql .= " WHERE e.enquiry_status_id = '" . (int)$data['filter_enquiry_status_id'] . "'";
		} else {
			$sql .= " WHERE e.enquiry_status_id > '0'";
		}
		if (!empty($data['filter_enquiry_id'])) {
			$sql .= " AND e.enquiry_id = '" . (int)$data['filter_enquiry_id'] . "'";
		}

		if (!empty($data['filter_customer'])) {
			$sql .= " AND LCASE(CONCAT(e.firstname, ' ', e.lastname)) LIKE '" . $this->db->escape(utf8_strtolower($data['filter_customer'])) . "%'";
		}

		if (!empty($data['filter_date_added'])) {
			$sql .= " AND DATE(e.date_added) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
		}
                
		if (!empty($data['filter_date_modified'])) {
			$sql .= " AND DATE(e.date_modified) = DATE('" . $this->db->escape($data['filter_date_modified']) . "')";
		}
		$query = $this->db->query($sql);

		return $query->row['total'];
	}
	
	
	
	public function addEnquiryToOrder($data = array()) {
	
            $enquiries_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "enquiry WHERE enquiry_id='".$data['enquiry_id']."' AND language_id = '" . (int)$this->config->get('config_language_id') . "'");
            foreach($enquiries_query->rows as $enquiry) {
                $this->db->query("INSERT INTO `" . DB_PREFIX . "order` SET  order_type_id='2',enquiry_id='".(int)$data['enquiry_id']."', invoice_no = '" . (int)$enquiry['invoice_no'] . "', invoice_prefix = '" . $this->db->escape($enquiry['invoice_prefix']) . "', store_id = '" . (int)$enquiry['store_id'] . "', store_name = '" . $this->db->escape($enquiry['store_name']) . "', store_url = '" . $this->db->escape($enquiry['store_url']) . "', customer_id = '" . (int)$enquiry['customer_id'] . "', customer_group_id = '" . (int)$enquiry['customer_group_id'] . "', firstname = '" . $this->db->escape($enquiry['firstname']) . "', lastname = '" . $this->db->escape($enquiry['lastname']) . "', email = '" . $this->db->escape($enquiry['email']) . "', telephone = '" . $this->db->escape($enquiry['telephone']) . "', fax = '" . $this->db->escape($enquiry['fax']) . "', shipping_firstname = '" . $this->db->escape($enquiry['shipping_firstname']) . "', shipping_lastname = '" . $this->db->escape($enquiry['shipping_lastname']) . "',  shipping_company = '" . $this->db->escape($enquiry['shipping_company']) . "', shipping_address_1 = '" . $this->db->escape($enquiry['shipping_address_1']) . "', shipping_address_2 = '" . $this->db->escape($enquiry['shipping_address_2']) . "', shipping_city = '" . $this->db->escape($enquiry['shipping_city']) . "', shipping_postcode = '" . $this->db->escape($enquiry['shipping_postcode']) . "', shipping_country = '" . $this->db->escape($enquiry['shipping_country']) . "', shipping_country_id = '" . (int)$enquiry['shipping_country_id'] . "', shipping_zone = '" . $this->db->escape($enquiry['shipping_zone']) . "', shipping_zone_id = '" . (int)$enquiry['shipping_zone_id'] . "', shipping_address_format = '" . $this->db->escape($enquiry['shipping_address_format']) . "', shipping_method = '" . $this->db->escape($enquiry['shipping_method']) . "', payment_firstname = '" . $this->db->escape($enquiry['payment_firstname']) . "', payment_lastname = '" . $this->db->escape($enquiry['payment_lastname']) . "', payment_company = '" . $this->db->escape($enquiry['payment_company']) . "', payment_address_1 = '" . $this->db->escape($enquiry['payment_address_1']) . "', payment_address_2 = '" . $this->db->escape($enquiry['payment_address_2']) . "', payment_city = '" . $this->db->escape($enquiry['payment_city']) . "', payment_postcode = '" . $this->db->escape($enquiry['payment_postcode']) . "', payment_country = '" . $this->db->escape($enquiry['payment_country']) . "', payment_country_id = '" . (int)$enquiry['payment_country_id'] . "', payment_zone = '" . $this->db->escape($enquiry['payment_zone']) . "', payment_zone_id = '" . (int)$enquiry['payment_zone_id'] . "', payment_address_format = '" . $this->db->escape($enquiry['payment_address_format']) . "', payment_method = '" . $this->db->escape($enquiry['payment_method']) . "', comment = '" . $this->db->escape($enquiry['comment']) . "', total = '" . (float)$data['whole_sale_price'] . "', order_status_id = '" . (int)$this->config->get('config_order_status_id') . "',reward='".(int)$enquiry['reward']."', affiliate_id  = '" . (int)$enquiry['affiliate_id'] . "', commission = '" . (float)$enquiry['commission']."', language_id =  '" . (int)$this->config->get('config_language_id') . "', currency_id = '" . (int)$enquiry['currency_id'] . "', currency_code = '" . $this->db->escape($enquiry['currency_code']) . "', currency_value = '" . (float)$enquiry['currency_value'] . "', ip = '" . $this->db->escape($enquiry['ip']) . "', date_added = NOW() , date_modified = NOW()");
          
                $order_id = $this->db->getLastId();

                if (isset($data['wholesale_product'])) {		
                        foreach ($data['wholesale_product'] as $enquiry_product) {	
                            $enquiries_prod_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "enquiry_product WHERE enquiry_id='".$enquiry['enquiry_id']."' AND enquiry_product_id = '" . (int)$enquiry_product['enquiry_product_id'] . "'");
                            $order_product=$enquiries_prod_query->row;

                            $this->db->query("INSERT INTO `" . DB_PREFIX . "order_product` SET order_id = '" . (int)$order_id . "', product_id = '" . (int)$order_product['product_id'] . "', name = '" . $this->db->escape($order_product['name']) . "', model = '" . $this->db->escape($order_product['model']) . "', quantity = '" . (int)$enquiry_product['quantity'] . "', price = '" . (float)$order_product['price'] . "', wholesale_price = '" . (float)$enquiry_product['wholesale_unit_price'] . "', total = '" . (float)$enquiry_product['price'] . "', tax = '" . (float)$order_product['tax'] . "'");

                            $this->db->query("UPDATE " . DB_PREFIX . "product SET quantity = (quantity - " . (int)$enquiry_product['quantity'] . ") WHERE product_id = '" . (int)$order_product['product_id'] . "' AND subtract = '1'");			
                          
                            $order_product_id = $this->db->getLastId();
                            if(isset($enquiry_product['option'])){
                                foreach ($enquiry_product['option'] as $option) {
                                        $this->db->query("INSERT INTO " . DB_PREFIX . "order_option SET order_id = '" . (int)$order_id . "', order_product_id = '" . (int)$order_product_id . "', product_option_id = '" . (int)$option['product_option_id'] . "', product_option_value_id = '" . (int)$option['product_option_value_id'] . "', name = '" . $this->db->escape($option['name']) . "', `value` = '" . $this->db->escape($option['value']) . "', `type` = '" . $this->db->escape($option['type']) . "'");
                                        $this->db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity - " . (int)$order_product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
                                   }
                            }
                            if(isset($enquiry_product['download'])){                            
                                foreach ($enquiry_product['download'] as $download) {
                                    $this->db->query("INSERT INTO " . DB_PREFIX . "order_download SET order_id = '" . (int)$order_id . "', order_product_id = '" . (int)$order_product_id . "', name = '" . $this->db->escape($download['name']) . "', filename = '" . $this->db->escape($download['filename']) . "', mask = '" . $this->db->escape($download['mask']) . "', remaining = '" . (int)($download['remaining'] * $enquiry_product['quantity']) . "'");
                                }                           
                            }
                        }
                }
				
                if((float)$data['shipping_price']>0)
                { 
                   $text_shipping_price = $this->currency->format($data['shipping_price']);
                   $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = 'shipping', title = '" . $this->db->escape($data['shipping_method']) . "', text = '" . $this->db->escape($text_shipping_price) . "', `value` = '" . (float)$data['shipping_price'] . "', sort_order = '" . (int)$this->config->get('shipping_sort_order') . "'");
				   
				   $text_sub_total_value=$data['whole_sale_price']-$data['shipping_price']; //sub total
                } else {
				   $text_sub_total_value=$data['whole_sale_price'];				
				}
				
			//---SUB TOTAL----
                $text_sub_total = $this->currency->format($text_sub_total_value);
                $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = 'sub_total', title = 'Sub-Total', text = '" . $this->db->escape($text_sub_total) . "', `value` = '" . (float)$text_sub_total_value . "', sort_order = '" . (int)$this->config->get('sub_total_sort_order') . "'"); 		
            //-----------				
				
               $text_total = $this->currency->format($data['whole_sale_price']);
               $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = 'total', title = 'Total', text = '" . $this->db->escape($text_total) . "', `value` = '" . (float)$data['whole_sale_price'] . "', sort_order = '" . (int)$this->config->get('total_sort_order') . "'"); 
               $this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$this->config->get('config_order_status_id') . "', notify = '1', comment = '', date_added = NOW()");             
            }   
            $this->db->query("INSERT INTO " . DB_PREFIX . "enquiry_history SET enquiry_id = '" . (int)$data['enquiry_id'] . "', enquiry_status_id = '" . (int)$this->config->get('config_enquiry_complete_status_id') . "', notify = '1', comment = '', date_added = NOW()");
            $this->db->query("UPDATE `" . DB_PREFIX . "enquiry` SET enquiry_status_id = '".(int)$this->config->get('config_enquiry_complete_status_id')."', order_id='".(int)$order_id."', total = '" . (float)$data['whole_sale_price'] . "' WHERE enquiry_id = '".(int) $data['enquiry_id']."'");			
        }
	
	public function deleteEnquiry($enquiry_id) {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "enquiry` WHERE enquiry_id = '" . (int)$enquiry_id . "'");
                $this->db->query("DELETE FROM " . DB_PREFIX . "enquiry_history WHERE enquiry_id = '" . (int)$enquiry_id . "'");
                $this->db->query("DELETE FROM " . DB_PREFIX . "enquiry_product WHERE enquiry_id = '" . (int)$enquiry_id . "'");
                $this->db->query("DELETE FROM " . DB_PREFIX . "enquiry_option WHERE enquiry_id = '" . (int)$enquiry_id . "'");
	  	$this->db->query("DELETE FROM " . DB_PREFIX . "enquiry_download WHERE enquiry_id = '" . (int)$enquiry_id . "'");
            	$this->db->query("DELETE FROM " . DB_PREFIX . "enquiry_total WHERE enquiry_id = '" . (int)$enquiry_id . "'");                
	}        
}
?>